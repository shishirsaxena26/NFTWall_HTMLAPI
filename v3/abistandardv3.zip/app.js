let web3;
web3 = new Web3(provider);

var BN = web3.utils.BN;
var bs1 = new web3.utils.BN("0");

let IPriceABI = {};
let ISafeguardABI = {};
let IHexBaseABI = {};
let I741RulesABI = {};
let INested741ABI = {};
let IInstanceMeABI = {};
let IORC1155ABI = {};
let IInstanceStorABI = {};
let IDAOCoreABI = {};
let IDAOAssemblyABI = {};
let ITransferRequestsABI = {};
let INFTProxyABI = {};
let INested741TVLABI = {};

let inprice = {};
let insafeguard = {};
let inHexBase = {};
let in741Rule = {};
let inNested741 = {};
let inInstanceMe = {};
let inORC1155 = {};
let indaocore = {};
let indaoassembly = {};
let inproposals = [];
let inNftProxy = {};
let invalidator;

let nested;
let price;
let rule;
let safeguard;
let daocore;
let daoassembly;
let transferRequests;
let nftProxy;
let validator;
let nested741TVL;
let currentAccount = null;
let currentInstance = null;
let currentStor = null;

const maxintervals = 30;
const doTVLClaim = false;
const doClaim = false;

let SIGNATURES;

const treeData = {
    id: "1",
    address: "0x0089188449F0d4119715c9A10eA8955FB26EE308",
    children: [
        {
            id: "2",
            address: "0x2242C969aaFD0D61Dd83e9a9c5E5dB046eeC922C",
            children: [
                {
                    id: "4",
                    address: "0x65595A6F3F2c71D2Daf9e816FbA3bfF80C8388c2",
                    children: [
                        {
                            id: "6",
                            address: "0x3700Ec1c787B382363f8CEF7c6605f6D8d8CBbBB",
                            children: [
                                {
                                    id: "8",
                                    address: "0x35312d50cf3c4ea8e997f2cB55c89b674E769161",
                                    children: [
                                        {
                                            id: "9",
                                            address: "0xBC422C995f416C44FDCD2f755622F74E76c1782f",
                                            children: [
                                                {
                                                    id: "10",
                                                    address: "0x38d8980013588181A3ee358F4aFcF573c1454A21",
                                                    children: [
                                                        {
                                                            id: "11",
                                                            address: "0x7017313e77417D9F66EFc6c4E38623Ec28E50266",
                                                            children: []
                                                        }
                                                    ]
                                                }
                                            ]
                                        }
                                    ]
                                }
                            ]
                        },
                        {
                            id: "7",
                            address: "0xE77aB47de567b3a79849F38dbAd1d321b3ACE9d8",
                            children: []
                        }
                    ]
                },
                {
                    id: "5",
                    address: "0x8fBD8b80F831735B1d0f21c67600e2b29a43A143",
                    children: [
                        {
                            id: "12",
                            address: "0xd2e355C594775d9cE44959C05879085c4fD94229",
                            children: []
                        }
                    ]
                }
            ]
        },
        {
            id: "3",
            address: "0x9653e22e7De603e3f4F80d6e6964Da487a4440bD",
            children: []
        }
    ]
};

const step = 5000;
let sysAge;
let rankClauses = {};


async function load() {
    await init();
    //loadRule();
    renderULTreePanel();
    renderTxLogPanel();

}

async function init() {

    //scanBlocks(50); // scan last 20 blocks
    IPriceABI = await fetch('abistandardv3/lib741Price.sol/lib741Price.json?v=' + version).then(res => res.json());
    ISafeguardABI = await fetch('abistandardv3/libSafeguard.sol/libSafeguard.json?v=' + version).then(res => res.json());
    IHexBaseABI = await fetch('abistandardv3/hexBase.sol/hexBase.json?v=' + version).then(res => res.json());
    I741RulesABI = await fetch('abistandardv3/lib741Rules.sol/lib741Rules.json?v=' + version).then(res => res.json());
    INested741ABI = await fetch('abistandardv3/Nested741.sol/Nested741.json?v=' + version).then(res => res.json());
    IInstanceMeABI = await fetch('abistandardv3/Nftwall-InstanceMe.sol/InstanceMe.json?v=' + version).then(res => res.json());
    IORC1155ABI = await fetch('abistandardv3/ORC1155.sol/ORC1155.json?v=' + version).then(res => res.json());
    IInstanceStorABI = await fetch('abistandardv3/InstanceStor.sol/InstanceStor.json?v=' + version).then(res => res.json());
    IDAOCoreABI = await fetch('abistandardv3/DAOCore.sol/DAOCore.json?v=' + version).then(res => res.json());
    IDAOAssemblyABI = await fetch('abistandardv3/DAOAssembly.sol/DAOAssembly.json?v=' + version).then(res => res.json());
    ITransferRequestsABI = await fetch('abistandardv3/TransferRequests.sol/TransferRequests.json?v=' + version).then(res => res.json());
    INFTProxyABI = await fetch('abistandardv3/NFTProxy.sol/NFTProxy.json?v=' + version).then(res => res.json());
    IValidatorsABI = await fetch('abistandardv3/NFTwallValidators.sol/NFTwallValidators.json?v=' + version).then(res => res.json());
    INested741TVLABI = await fetch('abistandardv3/Nested741TVL.sol/Nested741TVL.json?v=' + version).then(res => res.json());


    SIGNATURES = await fetch('abistandardv3/cache/signatures.json?v=' + version).then(res => res.json());

    inhexBase = hexBaseAddress;
    hexBase = new web3.eth.Contract(IHexBaseABI.abi, inhexBase);

    inNested741 = await hexBase.methods.in741().call();
    nested = new web3.eth.Contract(INested741ABI.abi, inNested741);
    sysAge = await nested.methods.systemAge().call();
    document.getElementById("sysAgeid").innerHTML = sysAge;

    in741Rule = await hexBase.methods.in741Rule().call();
    rule = new web3.eth.Contract(I741RulesABI.abi, in741Rule);

    insafeguard = await hexBase.methods.insafeguard().call();
    safeguard = new web3.eth.Contract(ISafeguardABI.abi, insafeguard);

    indaocore = await hexBase.methods.daocore().call();
    daocore = new web3.eth.Contract(IDAOCoreABI.abi, indaocore);

    indaoassembly = await hexBase.methods.daoassembly().call();
    daoassembly = new web3.eth.Contract(IDAOAssemblyABI.abi, indaoassembly);

    inInstanceMe = await hexBase.methods.inInstance().call();
    instanceme = new web3.eth.Contract(IInstanceMeABI.abi, inInstanceMe);

    inproposals.push(await hexBase.methods.proposals(0).call());
    transferRequests = new web3.eth.Contract(ITransferRequestsABI.abi, inproposals[0]);

    nested741TVL = new web3.eth.Contract(INested741TVLABI.abi, inNested741TVL);

    inPrice = await hexBase.methods.inPrice().call();
    price = new web3.eth.Contract(IPriceABI.abi, inPrice);
    console.log("💰 Ozone Price in USDT:",
        await price.methods.ozonePriceInUSDT().call()
    );

    invalidator = await hexBase.methods.invalidator().call();
    validator = new web3.eth.Contract(IValidatorsABI.abi, invalidator);

    inNftProxy = await hexBase.methods.inNftProxy().call();
    nftProxy = new web3.eth.Contract(INFTProxyABI.abi, inNftProxy);

    currentAccount = null;
    currentInstance = null;
    currentStor = null;

    if (window.ethereum) {
        window.ethereum.request({ method: 'eth_accounts' }).then(async (accounts) => {
            if (accounts.length) {
                currentAccount = accounts[0];
                showWallet();
                await addConnectedUserPanel();
            }
        });
    }

    hideLoader();
    //name(); 
    //debugTransaction();
    //scanBlocks(50); // scan last 20 blocks
    //loadRule();

}

async function name() {

    const orc1155contract = new web3.eth.Contract(IORC1155ABI.abi, "0xC9627f194Cb4Ed859132F3f9D0E0577ee9c9f443");
    const events = await orc1155contract.getPastEvents("TransferSingle", {
        fromBlock: minBlock,
        toBlock: parseInt(minBlock) + 10000
    });
    console.log(events);
}

async function _callpayload() {
    const data = web3.eth.abi.encodeFunctionCall({
        name: "subscribed",
        type: "function",
        inputs: [
            { type: "address", name: "_user" }
        ]
    }, ["0xE77aB47de567b3a79849F38dbAd1d321b3ACE9d8"]);

    const payload = web3.eth.abi.encodeParameters(
        ["address", "bytes"],
        ["0xFcb3B3914e3E93040884696De45fb99b1a8Cbb90", data]
    );

    window.web3T = new Web3(window.ethereum);
    // Initialize contract
    const hexcontract = new web3T.eth.Contract(IHexBaseABI.abi, inhexBase);
    // Send transfer
    const tx = await hexcontract.methods
        .onTokenTransfer(payload)
        .send({ from: currentAccount });

    console.log(tx);

    if (tx.status)
        alert("Burning succeeded");
    else
        throw "Burning failed";

}

async function scanBlocks(limit = 10) {


    const latestBlock = await web3.eth.getBlockNumber();
    //console.log("Latest Block:", latestBlock);

    for (let i = latestBlock; i > 0; i--) {

        const block = await web3.eth.getBlock(i, true); // true = include tx objects
        if (block.transactions.length == 0) continue;
        console.log("------------------------------------------------");


        console.log("Block Number:", block.number);
        console.log("Block Hash:", block.hash);
        console.log("Timestamp:", block.timestamp);
        console.log("Miner:", block.miner);
        console.log("Gas Used:", block.gasUsed);
        console.log("Transaction Count:", block.transactions.length);

        block.transactions.forEach((tx, index) => {
            console.log("   TX#", index + 1);
            console.log("   Hash:", tx.hash);
            console.log("   From:", tx.from);
            console.log("   To:", tx.to);
            console.log("   Value:", web3.utils.fromWei(tx.value, "ether"), "ETH");
            console.log("   Gas:", tx.gas);
            console.log("   GasPrice:", tx.gasPrice);
            console.log("   Nonce:", tx.nonce);
            console.log("   Input:", tx.input);
            console.log("   ---------------------------");
        });

    }
}

async function debugTransaction() {
    const txHash = "0xa4de0d0d4355b21d9158ead76af831b1505de7d99b10ac543eb7293f66592501";
    web3.currentProvider.send(
        {
            jsonrpc: "2.0",
            method: "debug_traceTransaction",
            params: [
                txHash,
                { tracer: "callTracer" }
            ],
            id: 1
        },
        function (err, result) {
            if (err) {
                console.error("Debug error:", err);
                return;
            }

            console.log("Trace result:", result);

            /* OPTIONAL: Also fetch receipt */

            web3.eth.getTransactionReceipt(txHash)
                .then(function (receipt) {

                    console.log("Transaction Receipt:", receipt);

                    if (receipt && receipt.logs) {

                        console.log("Event Logs:");

                        receipt.logs.forEach(function (log, i) {

                            console.log("Log #" + i, log);

                        });

                    }

                })
                .catch(function (err) {
                    console.error("Error fetching receipt:", err);
                });

        }
    );
}



// -------------------- PANEL FUNCTIONS --------------------
function clearPanels() {
    document.getElementById("systemPanels").innerHTML = "";
}

function renderAddress(value) {
    const v = document.createElement("div");

    if (typeof value === "string" && value.startsWith("0x")) {
        v.className = "addr";

        const short = document.createElement("span");
        short.className = "shortAddr";
        short.innerText = value.slice(0, 6) + "..." + value.slice(-4);
        short.style.cursor = "pointer";

        short.onclick = async () => {
            await navigator.clipboard.writeText(value);

            // flash copied effect
            const oldText = short.innerText;

            short.innerText = "Copied ✓";
            short.style.opacity = "0.5";

            setTimeout(() => {
                short.innerText = oldText;
                short.style.opacity = "1";
            }, 800);
        };

        v.appendChild(short);
    }
    else {
        v.innerText = value;
    }

    return v;
}

function renderAddressLongX(value) {
    const v = document.createElement("div");

    if (typeof value === "string" && value.startsWith("0x")) {
        v.className = "addr";

        const short = document.createElement("span");
        short.className = "shortAddr";
        short.innerText = value.slice(0, 10) + "..." + value.slice(-10);
        short.style.cursor = "pointer";

        short.onclick = async () => {
            await navigator.clipboard.writeText(value);

            // flash copied effect
            const oldText = short.innerText;

            short.innerText = "Copied ✓";
            short.style.opacity = "0.5";

            setTimeout(() => {
                short.innerText = oldText;
                short.style.opacity = "1";
            }, 800);
        };

        v.appendChild(short);
    }
    else {
        v.innerText = value;
    }

    return v;
}

function addPanel(title) {
    const panel = document.createElement("div");
    panel.className = "panel";
    const h3 = document.createElement("h3");
    h3.innerText = title;
    panel.appendChild(h3);
    document.getElementById("systemPanels").appendChild(panel);
    return panel;
}

function removePanelIfExists(title) {
    const panels = document.querySelectorAll("#systemPanels .panel");
    panels.forEach(panel => {
        const h3 = panel.querySelector("h3");

        if (h3 && h3.innerText === title) {
            panel.remove();
        }
    });
}

function removePanel(title) {
    const panels = document.querySelectorAll("#systemPanels .panel");

    panels.forEach(panel => {
        const h3 = panel.querySelector("h3");

        if (h3 && h3.childNodes[0].textContent.trim() === title) {
            panel.remove();
        }
    });
}
function addRow(panel, field, value) {

    const row = document.createElement("div");
    row.className = "row";
    row.style.whiteSpace = "pre";
    row.style.fontFamily = "monospace";

    const f = document.createElement("div");

    if (field instanceof HTMLElement) {
        f.appendChild(field);
        row.appendChild(f);
    }
    else {
        if (field != "") {
            f.innerText = field;
            row.appendChild(f);
        }
    }

    const v = document.createElement("div");

    if (value instanceof HTMLElement) {

        v.width = "100%";
        v.appendChild(value);

    }
    else if (typeof value === "string" && value.startsWith("0x")) {

        v.className = "addr";

        const short = document.createElement("span");
        short.className = "shortAddr";
        short.innerText = value.slice(0, 6) + "..." + value.slice(-4);
        short.style.cursor = "pointer";

        // click to copy
        short.onclick = async () => {

            await navigator.clipboard.writeText(value);

            const oldText = short.innerText;

            short.innerText = "Copied ✓";
            short.style.opacity = "0.5";

            setTimeout(() => {
                short.innerText = oldText;
                short.style.opacity = "1";
            }, 800);
        };

        const balpanel = document.createElement("span");
        balpanel.className = "shortAddr";

        printRow(value, balpanel);

        v.appendChild(short);
        v.append(balpanel);

    }
    else {

        v.innerText = value;
    }

    row.appendChild(v);
    panel.appendChild(row);
}

function shortAddr(addr) {
    if (!addr) return "";
    if (addr.length <= 10) return addr;
    return addr.slice(0, 6) + "..." + addr.slice(-4);
}

function pad3(v) {
    v = parseInt(v);
    if (v >= 100) return v.toString();
    if (v >= 10) return "0" + v;
    return "00" + v;
}

function padStr(v, len = 20) {
    return String(v).padStart(len, ' ');
}

// Helper: format wei → OZN with 3 decimals
function formatOZN(value) {
    if (!value) return "NULL";
    return Number(web3.utils.fromWei(value, "ether")).toFixed(12);
}

async function printRow(addr, balpanel) {
    const bal = await web3.eth.getBalance(addr);
    /* let eth3 = new web3.utils.BN(bal).div(new web3.utils.BN("1000000000"));
     let major = eth3.div(new web3.utils.BN("1000")).toString();
     let minor = pad3(eth3.mod(new web3.utils.BN("1000")).toString()); */

    let res = " | " + Number(web3.utils.fromWei(bal, "ether")).toFixed(12) + " OZN";
    balpanel.innerText = res;
    return res;
}

// -------------------- LOAD SYSTEM --------------------
async function loadSystem() {
    clearPanels();
    const panelSys = addPanel("System Data");
    try {
        const nodes = await nested.methods.getNodesCount().call();
        sysAge = await nested.methods.systemAge().call();
        document.getElementById("sysAgeid").innerHTML = sysAge;
        const isSafe = await safeguard.methods.isSafe().call();

        addRow(panelSys, "Nodes Count", nodes);
        addRow(panelSys, "System Age", `${getAgeDateRange(sysAge).start} {${sysAge}}`);
        addRow(panelSys, "Is Safe", isSafe);

        addRow(panelSys, "Price Rate", formatOZN(await price.methods.ozonePriceInUSDT().call()));
        await loadSystemTreasuriesNSecurebase();

    } catch (err) {
        console.error(err);
        addRow(panelSys, "Error", "Unable to load marketplace");
    }

    //await onGetDailyBusiness();
    hideLoader();
    //setTimeout(() => loadSystem(), 15000);

}

// -------------------- SYSTEM TREASURY + SECUREBASE --------------------
async function loadSystemTreasuriesNSecurebase() {
    const container = document.getElementById("systemPanels");

    const panelBase = addPanel("BASE");
    const link = document.createElement("a");

    link.innerText = "HexBase";
    link.href = "#"; // prevent navigation
    // apply color
    link.style.color = "var(--text)";
    link.addEventListener("click", function (e) {
        e.preventDefault(); // stop page jump
        const _p = prompt("Enter hexbase address:");
        const _hex = _p.trim();
        if (!_hex || !web3.utils.isAddress(_hex)) {
            alert("Enter a valid hexbase address");
            return;
        }
        hexBaseAddress = _hex;
        init();
    });
    addRow(panelBase, link, hexBaseAddress);


    const deployer = await hexBase.methods.inDeployerAsRoot().call();
    addRow(panelBase, "DeployerAsRoot", deployer);

    const deployerasservice = await hexBase.methods.inDeployerAService().call();
    addRow(panelBase, "DeployerAsService", deployerasservice);

    addRow(panelBase, "insafeguard", insafeguard);

    addRow(panelBase, "inPrice", inPrice);

    const old741 = await hexBase.methods.in741Old().call();
    addRow(panelBase, "in741Old", old741);
    addRow(panelBase, "in741Rule", in741Rule);
    addRow(panelBase, "in741", inNested741);

    const daoCore = await hexBase.methods.daocore().call();
    addRow(panelBase, "DAO Core", daoCore);
    const daoAsm = await hexBase.methods.daoassembly().call();
    addRow(panelBase, "DAO Assembly", daoAsm);

    const prop0 = await hexBase.methods.proposals(0).call();
    addRow(panelBase, "proposal(0)", prop0);
    const inst = await hexBase.methods.inInstance().call();
    addRow(panelBase, "instance", inst);
    const inInstanceStor = await hexBase.methods.inInstanceStor().call();

    addRow(panelBase, "stor", inInstanceStor);
    const nftproxy = await hexBase.methods.inNftProxy().call();
    addRow(panelBase, "NFTProxy", nftproxy);
    const nftvalidator = await hexBase.methods.invalidator().call();
    addRow(panelBase, "Validator", nftvalidator);

    addRow(panelBase, "inNested741TVL", inNested741TVL);

    const panelTreasury = addPanel("TREASURY");
    const factory = await hexBase.methods.inTreaseryFactory().call();
    addRow(panelTreasury, "Factory", factory);
    const mining = await hexBase.methods.inTreaseryTVLMining().call();
    addRow(panelTreasury, "TVL Mining", mining);
    /*
    const reward = await hexBase.methods.inTreaseryTVLReward().call();
    addRow(panelTreasury, "TVL Reward", reward);
    const roy = await hexBase.methods.inTreaseryTVLRoyality().call();
    addRow(panelTreasury, "TVL Royality", roy);
    const val = await hexBase.methods.inTreaseryTVLValidator().call();
    addRow(panelTreasury, "TVL Validator", val);
    */
    const panelByteCode = addPanel("BYTECODE");
    addRow(panelByteCode, "Bytecode", byteCodeStandard);
    addRow(panelByteCode, "Download ABI", "https://drive.google.com/drive/folders/1O4J0hFtdSdbBcDyA5SxrLUOM8NqtQl0-");

    //////////////////////////////////////////
    ///////////////////////////////////////////

    const panelSecure = addPanel("SECUREBASE");
    const propSafe = await safeguard.methods.isSecureBase(prop0).call();
    addRow(panelSecure, "proposal(0)", propSafe);

    //////////////////////////////////////////
    ///////////////////////////////////////////

    const panelPorp = addPanel("PROPOSALS(0)");
    const importedNodeCount = await transferRequests.methods.getimportedNodeCount().call();
    const forms = await transferRequests.methods.getFormsCount().call();
    const actualTVL = await transferRequests.methods.actualTVL().call();

    addRow(panelPorp, "Form Count", forms);
    addRow(panelPorp, "Imported Users", importedNodeCount);
    addRow(panelPorp, "ActualTVL", formatOZN(actualTVL));
    try {
        const panelOther = addPanel("OTHERS");
        const currentnode = await nested741TVL.methods.currentnode().call();
        addRow(panelOther, "Currentnode", currentnode);
    }
    catch {

    }
    //////////////////////////////////////////
    ///////////////////////////////////////////

    const panelBusiness = addPanel("Business");

    const rBusiness = document.createElement("div");

    const btnExecuteRoyality = document.createElement("button");
    btnExecuteRoyality.innerText = "ExecuteRoyality";
    btnExecuteRoyality.style.marginLeft = "10px";
    btnExecuteRoyality.onclick = () => {
        onExecuteRoyality();
    };

    const btnDefaultRankCount = document.createElement("button");
    btnDefaultRankCount.innerText = "DefaultRankCount";
    btnDefaultRankCount.style.marginLeft = "10px";
    btnDefaultRankCount.onclick = () => {
        onSetDefaultRankCount();
    };


    const btnBusiness = document.createElement("button");
    btnBusiness.innerText = "GetBusiness";
    btnBusiness.style.marginLeft = "10px";
    btnBusiness.onclick = () => {
        onGetDailyBusiness();
    };

    rBusiness.appendChild(btnDefaultRankCount);
    rBusiness.appendChild(btnExecuteRoyality);
    rBusiness.appendChild(btnBusiness);

    addRow(panelBusiness, "Click to get business", rBusiness);
    // Create table
    const table1 = document.createElement("table");
    table1.id = "tabDailyBusiness";
    table1.border = "1";
    table1.style.width = "100%";

    // Add header
    table1.innerHTML = `
    <thead>
    <tr>
    <th>Day</th><th>Business</th><th>Withdrawn</th><th>Joining</th>
    <th>(Ct0+4)</th><th>Ct1</th><th>Ct2</th><th>Ct3</th>
    <th>Ct4</th><th>Ct5</th><th>Ct6</th><th>Ct7</th>
    <th>Royal3</th><th>Royal5</th><th>Royal7</th>
    </tr>
    </thead>
    <tbody id="tabDBBody"></tbody>
    `;


    const idSpan = document.createElement("span");


    addRow(panelBusiness, "", table1);
    //onGetDailyBusiness();

}

async function onExecuteRoyality() {

    // Enable wallet
    window.web3T = new Web3(window.ethereum);
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    const nestedContractV1 = new web3T.eth.Contract(INested741ABI.abi, inNested741);

    const tx = await nestedContractV1.methods
        .compileRoyality(systemAge)
        .send({
            from: accounts[0]
        });

    if (tx.status) {
        alert("ExecuteRoyality succeeded");
    } else {
        alert("ExecuteRoyality failed");
    }


}

async function onSetDefaultRankCount() {

    // Enable wallet
    window.web3T = new Web3(window.ethereum);
    const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
    const nestedContractV1 = new web3T.eth.Contract(INested741ABI.abi, inNested741);

    const tx = await nestedContractV1.methods
        .setDefaultRankCount(400)
        .send({
            from: accounts[0]
        });

    if (tx.status) {
        alert("setDefaultRankCount succeeded");
    } else {
        alert("setDefaultRankCount failed");
    }
}

async function onGetDailyBusiness() {
    showLoader();
    var r3 = new BN("0");
    var r5 = new BN("0");
    var r7 = new BN("0");
    document.getElementById("tabDBBody").replaceChildren();
    document.getElementById("tabDBBody").innerHTML = "";

    let age = await nested.methods.systemAge().call();

    document.getElementById("sysAgeid").innerHTML = age;
    for (let i = parseInt(age); i >= parseInt(age) - 15; i--) {
        let b = await nested.methods.getbusiness(i).call();
        let w = await nested.methods.getwithdrawn(i).call();
        let j = await nested.methods.getjoining(i).call();


        let Ct0 = await nested.methods.getrankCount(i, 0).call();
        let Ct1 = await nested.methods.getrankCount(i, 1).call();
        let Ct2 = await nested.methods.getrankCount(i, 2).call();
        let Ct3 = await nested.methods.getrankCount(i, 3).call();
        let Ct4 = await nested.methods.getrankCount(i, 4).call();
        let Ct5 = await nested.methods.getrankCount(i, 5).call();
        let Ct6 = await nested.methods.getrankCount(i, 6).call();
        let Ct7 = await nested.methods.getrankCount(i, 7).call();
        var royal3 = new BN('0');
        var royal5 = new BN('0');
        var royal7 = new BN('0');

        if (parseInt(Ct3) > 0) {
            royal3 = (new BN(((new BN(b)).mul(new BN("18")).div(new BN("1000"))).toString())).div(new BN(Ct3.toString()));
        }
        if (parseInt(Ct5) > 0) {
            royal5 = (new BN(((new BN(b)).mul(new BN("18")).div(new BN("1000"))).toString())).div(new BN(Ct5.toString()));
        }
        if (parseInt(Ct7) > 0) {
            royal7 = (new BN(((new BN(b)).mul(new BN("9")).div(new BN("1000"))).toString())).div(new BN(Ct7.toString()));
        }

        r3 = r3.add(new BN(royal3.toString()));
        r5 = r5.add(new BN(royal5.toString()));
        r7 = r7.add(new BN(royal7.toString()));

        //console.log(r3.toString());
        //console.log(r5.toString());
        //console.log(r7.toString());
        // 1. Check addresses
        //console.log("nested:", nested.options.address);

        //let in741Addr = await hexBase.methods.in741().call();
        //console.log("in741:", in741Addr);
        let constRoyal = await nested.methods.getRoyalityAmountBatch(i).call();

        console.log(`i: ${getAgeDateRange(i).start} {${i}}`);
        console.log(`constRoyal: ${constRoyal}`);
        document.getElementById("tabDBBody")
            .insertAdjacentHTML("beforeend",
                '<tr><td>' + `${getAgeDateRange(i).start} {${i}}` + '</td><td>' + b + '</td><td>' + w + '</td><td>' + j + '</td><td>' + Ct0 + '</td><td>' + Ct1 + '</td><td>' + Ct2 + '</td><td>' + Ct3 + '</td><td>' + Ct4 + '</td><td>' + Ct5 + '</td><td>' + Ct6 + '</td><td>' + Ct7 + '</td><td>' + constRoyal[2].toString() + '</td><td>' + constRoyal[4].toString() + '</td><td>' + constRoyal[6].toString() + '</td></tr>'
            );
    }



    hideLoader();

}

//NOT IN USED
// -------------------- LOAD USER (NOT IN USED) --------------------
async function loadUserPanel(user) {
    if (!user || !web3.utils.isAddress(user)) {
        alert("Please enter a valid address");
        return;
    }

    clearPanels();

    const userPanel = addPanel("User Data");

    //const user = "0xE77aB47de567b3a79849F38dbAd1d321b3ACE9d8";
    const id = await nested.methods.UserToId(user).call();
    const node = await nested.methods.getNode(id).call();
    const isdelegator = await nested.methods._isDelegatorNode(user).call();

    addRow(userPanel, "--", node[0]);
    addRow(userPanel, "Node", node[1]);
    addRow(userPanel, "Are you Delegator ", isdelegator);
    addRow(userPanel, "Parent", node[2]);
    addRow(userPanel, "Active", node[5]);
    addRow(userPanel, "Direct Count", node[6]);

    const instAddr = node[3];
    const storAddr = node[4];

    if (instAddr != "0x0000000000000000000000000000000000000000") {
        const inst = new web3.eth.Contract(IInstanceMeABI.abi, instAddr);
        const instId = await inst.methods.id().call();
        const instParent = await inst.methods.parent().call();
        const instStor = await inst.methods.stor().call();

        addRow(userPanel, "Instance ID", instId);
        addRow(userPanel, "Instance Parent", instParent);
        addRow(userPanel, "Instance Stor", instStor);
    }

    const stor = new web3.eth.Contract(IInstanceStorABI.abi, storAddr);
    const dage = await stor.methods.dage().call();
    const rankWithAge = await stor.methods.getRankWithAgeValue().call();
    const cage = await stor.methods.cage().call();
    const activedirectsCount = await stor.methods.activedirectsCount().call();
    addRow(userPanel, "Active Direct Count", activedirectsCount);
    addRow(userPanel, "Stor Cage", cage);
    addRow(userPanel, "Stor Dage", `${getAgeDateRange(dage).start} {${dage}}`);
    addRow(userPanel, "Stor Rank", `Rank: ${rankWithAge[0]} as on ${getAgeDateRange(rankWithAge[1]).start} {${rankWithAge[1]}}`);
    const table = document.createElement("table");
    table.border = "1";
    table.cellPadding = "5";
    table.style.width = "100%";
    // ✅ THEAD (Header)
    const thead = document.createElement("thead");
    thead.innerHTML = `
        <tr>
            <th>#</th>
            <th>Desc</th>
            <th>Target</th>
            <th>Up</th>
            <th>Dn</th>
            <th>Win</th>
            <th>Approved</th>
            <th>Resolved</th>
            <th>Creator</th>
            <th>Vote</th>
            <th>Sign</th>
        </tr>
        `;
    table.appendChild(thead);

    addRow(userPanel, "", table);


}

async function addConnectedUserPanel() {


    const btnLogin = document.getElementById("btnLogin");
    const btnJoin = document.getElementById("btnJoin");
    const btnInit = document.getElementById("btnInit");
    const btnImport = document.getElementById("btnImport");

    btnLogin.style.display = "none";
    btnJoin.style.display = "none";
    btnInit.style.display = "none";
    btnImport.style.display = "none";

    if (!currentAccount || !web3.utils.isAddress(currentAccount)) return;

    try {

        document.getElementById("userAddrInput").value = currentAccount;
        const id = await nested.methods.UserToId(currentAccount).call();
        const node = await nested.methods.getNode(id).call();

        document.getElementById("walletId").innerText =
            "ID " + node[0];

        currentInstance = node[3];
        currentStor = node[4];

        /*
         STEP 1
         No instance yet
         */

        if (node[3] == ZERO) {
            btnJoin.style.display = "block";
            return;
        }

        /*
        STEP 2
        Import instance
        */
        if (node[3] != ZERO && node[4] != ZERO) {
            currentInstance = node[3];
            currentStor = node[4];
            document.getElementById("walletInst").innerText =
                "Inst " + shortAddr(currentInstance);
            document.getElementById("walletStor").innerText =
                "Stor " + shortAddr(currentStor);

            const stor = new web3.eth.Contract(IInstanceStorABI.abi, currentStor);
            const postInit = await stor.methods.postInit().call();
            if (!postInit) {
                btnImport.style.display = "block";
                return;
            } else {
                const instan = new web3.eth.Contract(IInstanceMeABI.abi, currentInstance);
                if (await instan.methods.validateToken().call()) {
                }
                else {
                    btnLogin.style.display = "block";
                    return;
                }
            }

        }

    } catch (e) {
        console.log(e);
        document.getElementById("walletNode").innerText = "User not registered";
    }
}

function updatePanelWithInstance(instance) {

    document.getElementById("walletInst").innerText =
        "Inst " + shortAddr(instance);

    document.getElementById("btnJoin").style.display = "none";
    document.getElementById("btnInit").style.display = "block";
}

async function joinUser() {
    try {

        let accounts = await ethereum.enable();
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        window.web3T = new Web3(window.ethereum);
        if (!currentAccount || !web3.utils.isAddress(currentAccount)) {
            alert("Connect to wallet");
            return;
        }


        let parent = ZERO;
        const resolveTarget = await transferRequests.methods.resolveTransferTarget(currentAccount).call();
        if (resolveTarget == ZERO) {
            const _p = prompt("Enter parent address:");
            parent = _p.trim();
            if (!parent || !web3.utils.isAddress(parent)) {
                alert("Enter a valid parent");
                return;
            }
        }


        // encode constructor args
        //const iface = new ethers.utils.Interface(IInstanceMeABI.abi);
        //const encodedArgs = iface.encodeDeploy([hexBaseAddress, parent]);

        // append args to bytecode
        //const deployBytecode = byteCodeStandard + encodedArgs.slice(2);

        const contract = new web3T.eth.Contract(IInstanceMeABI.abi);
        // deploy transaction
        const deployTx = contract.deploy({
            data: byteCodeStandard,
            arguments: [hexBaseAddress, parent]
        });

        const gas = await deployTx.estimateGas({ from: currentAccount });

        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        const tx = await deployTx.send({
            from: currentAccount,
            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1", // small tip
            maxFeePerGas: (baseFee + 2n).toString() // just above base fee
        });

        console.log("Deploy TX:", tx);

        // contract address from receipt
        currentInstance = tx.options.address;;
        alert("User Joined: " + currentInstance);
        // update UI
        document.getElementById("walletInst").innerText =
            "Inst " + shortAddr(currentInstance);

        document.getElementById("btnJoin").style.display = "none";
        document.getElementById("btnInit").style.display = "block";

    } catch (e) {
        console.error(e);
        alert(e.message);
    }

    hideLoader();
}

async function initUser() {

    if (!currentInstance) {
        alert("Instance not found");
        return;
    }

    try {

        let accounts = await ethereum.enable();
        window.web3T = new Web3(window.ethereum);
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const instancecontract = new web3T.eth.Contract(
            IInstanceMeABI.abi,
            currentInstance
        );

        instancecontract.methods.owner().call(console.log);
        instancecontract.methods.getHexbase().call(console.log);

        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        // estimate gas
        const gas = await instancecontract.methods
            .initialize()
            .estimateGas({
                from: currentAccount,
                value: "0"
            });

        // send transaction
        const receipt = await instancecontract.methods
            .initialize()
            .send({
                from: currentAccount,
                value: "0",

                gas: Math.floor(gas * 1.1), // small buffer

                maxPriorityFeePerGas: "1", // low tip
                maxFeePerGas: (baseFee + 2n).toString() // just above base fee
            });

        console.log("Instance initialized");

        // reload panel so stor address appears
        await addConnectedUserPanel();

    } catch (e) {
        console.log(e);
        alert("Transfer failed: " + (e.message || e));
    }
    hideLoader();
}

async function loginUser1() {

    if (!currentInstance) {
        alert("Instance not found");
        return;
    }

    try {

        let accounts = await ethereum.enable();
        window.web3T = new Web3(window.ethereum);
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const instancecontract = new web3T.eth.Contract(
            IInstanceMeABI.abi,
            currentInstance
        );
        const tx = await instancecontract.methods.login(maxintervals, doTVLClaim, doClaim).send({ from: accounts[0] });
        if (tx.status) {
            alert("Login succeeded");
        }
        else {
            alert("Login failed");
        }
        // reload panel so stor address appears
        await addConnectedUserPanel();

    } catch (e) {


        alert("Login failed: " + (e.message));
    }
    hideLoader();
}

async function loginUser() {

    if (!currentInstance) {
        alert("Instance not found");
        return;
    }

    try {

        let accounts = await ethereum.enable();
        window.web3T = new Web3(window.ethereum);
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const instancecontract = new web3T.eth.Contract(
            IInstanceMeABI.abi,
            currentInstance
        );


        instancecontract.methods.owner().call(console.log);
        instancecontract.methods.getHexbase().call(console.log);

        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        debugger;
        // estimate gas
        const gas = await instancecontract.methods
            .login(maxintervals, doClaim)
            .estimateGas({
                from: currentAccount,
                value: "0"
            });

        // send transaction
        const tx = await instancecontract.methods.
            login(maxintervals, doClaim)
            .send({
                from: currentAccount,
                value: "0",

                gas: Math.floor(gas * 1.1), // small buffer

                maxPriorityFeePerGas: "1", // low tip
                maxFeePerGas: (baseFee + 2n).toString() // just above base fee
            });

        alert("Login successful");

        // reload panel so stor address appears
        await addConnectedUserPanel();

    } catch (e) {


        alert("Login failed: " + (e.message));
    }
    hideLoader();
}

async function importUser() {

    try {

        let accounts = await ethereum.enable();
        window.web3T = new Web3(window.ethereum);
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }
        const userId = await nested.methods.UserToId(currentAccount).call();
        if (userId == 0) { alert("Invalid user"); return; }

        const stor = new
            web3T.eth.Contract(IInstanceStorABI.abi,
                currentStor);

        const postInit = await stor.methods.postInit().call();

        const nestedcontract = new
            web3T.eth.Contract(INested741ABI.abi,
                inNested741);
        debugger;
        if (postInit) { alert('already imported'); return; }

        const limit = 5; // change according to your import batch size
        await nestedcontract.methods
            .importOld(userId, limit)
            .send({
                from: currentAccount,
                value: "0"
            });

        console.log("Import completed");

        await addConnectedUserPanel();

    } catch (e) {
        console.log(e);
        alert("Transfer failed: " + (e.message || e));
    }
    hideLoader();
}

async function buyNFT(o1155, tokenId) {
    showLoader();
    try {

        //buyNFTForOther(o1155, tokenId); return;

        if (!currentAccount) {
            alert("Connect wallet first");
            return;
        }

        if (currentInstance == null || currentInstance == '0x0000000000000000000000000000000000000000') {
            alert("invalid instance");
            return;
        }

        if (currentStor == null || currentStor == '0x0000000000000000000000000000000000000000') {
            alert("invalid stor");
            return;
        }

        const qty = prompt("Enter buy amount:");
        if (!qty) {
            throw 'buy amount required';
        }

        let accounts = await ethereum.enable();
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }
        window.web3T = new Web3(window.ethereum);
        const instancecontract = new web3T.eth.Contract(IInstanceMeABI.abi, currentInstance);
        const storcontract = new web3.eth.Contract(IInstanceStorABI.abi, currentStor);

        const valid =
            await instancecontract.methods.validateToken().call({
                from: accounts[0]
            });

        if (!valid) {
            throw "Login required";
        }

        // qty = 1 (market purchase)

        //const tokenid = i;

        // get mint value
        let value = BigInt(
            await rule.methods
                .computeMintValue(qty)
                .call()
        );

        // check bonus
        let bonus = BigInt(
            await storcontract.methods
                .bonus()
                .call()
        );

        // reduce bonus
        value = bonus >= value ? 0n : (value - bonus);

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        ;
        // estimate gas
        const gas = await instancecontract.methods
            .Txn(o1155, tokenId, qty, 101)
            .estimateGas({
                from: accounts[0],
                value: value.toString()
            });

        // send transaction
        const receipt = await instancecontract.methods
            .Txn(o1155, tokenId, qty, 101)
            .send({
                from: accounts[0],
                value: value.toString(),

                gas: Math.floor(gas * 1.1), // small buffer

                maxPriorityFeePerGas: "1", // low tip
                maxFeePerGas: (baseFee + 2n).toString() // just above base fee
            });

        if (receipt.status) {
            alert("NFT Purchased");
        } else {
            alert("NFT Failed");
        }

    } catch (e) {
        console.error(e);
        alert("Purchased failed: " + (e.message || e));
    }
    hideLoader();
}


async function buyNFTForOther(o1155, tokenId) {
    showLoader();
    try {


        const qty = prompt("Enter buy amount:");
        if (!qty) {
            throw 'buy amount required';
        }

        let accounts = await ethereum.enable();
        window.web3T = new Web3(window.ethereum);

        currentInstance = '0x1d37E94c45d3323cE1F1b86f87C1cd311861C8BA';
        const instancecontract = new web3T.eth.Contract(IInstanceMeABI.abi, currentInstance);

        const valid =
            await instancecontract.methods.validateToken().call({
                from: accounts[0]
            });

        if (!valid) {
            throw "Login required";
        }

        // get mint value
        let value = BigInt(
            await rule.methods
                .computeMintValue(qty)
                .call()
        );

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        // estimate gas
        const gas = await instancecontract.methods
            .Txn(o1155, tokenId, qty, 101)
            .estimateGas({
                from: accounts[0],
                value: value.toString()
            });

        // send transaction
        const receipt = await instancecontract.methods
            .Txn(o1155, tokenId, qty, 101)
            .send({
                from: accounts[0],
                value: value.toString(),

                gas: Math.floor(gas * 1.1), // small buffer

                maxPriorityFeePerGas: "1", // low tip
                maxFeePerGas: (baseFee + 2n).toString() // just above base fee
            });



        if (receipt.status) {
            alert("NFT Purchased");
        } else {
            alert("NFT Failed");
        }

    } catch (e) {
        console.error(e);
        alert("Purchased failed: " + (e.message || enabled));
    }
    hideLoader();
}

async function loadID() {
    try {
        const uid = prompt("Enter ID:");
        if (!uid && parseInt(uid) > 0)
            throw 'valid ID required';
        const user = await nested.methods.nodes(uid).call();
        if (user == ZERO) alert("No user found");
        else document.getElementById("userAddrInput").value = user;

    } catch (err) {
        console.error(err);
        alert("Failed: " + (err.message || err));
    }

    hideLoader();
}

// -------------------- LOAD USER FULL --------------------
async function loadUser() {
    const input = document.getElementById("userAddrInput");
    const user = input.value.trim();
    if (!user || !web3.utils.isAddress(user)) {
        alert("Enter a valid Ethereum address");
        return;
    }

    clearPanels();



    const panel = addPanel("User Data");
    try {

        sysAge = await nested.methods.systemAge().call();
        document.getElementById("sysAgeid").innerHTML = sysAge;

        const id = await nested.methods.UserToId(user).call();
        const node = await nested.methods.getNode(id).call();
        const isdelegator = await nested.methods._isDelegatorNode(user).call();
        const isdelegatorNode = await daoassembly.methods.isdelegatorNode(user).call();
        const teamSizeAndZeroDownlevelCount = await nested.methods.getTotalTeamSizeWithLevel(user, 1).call();

        addRow(panel, "ID", node[0]);
        addRow(panel, "Node", node[1]);
        addRow(panel, "Parent", node[2]);
        addRow(panel, "Active", node[5]);
        addRow(panel, "Direct Count", node[6]);
        addRow(panel, "Downline Size (1 level)", teamSizeAndZeroDownlevelCount[1]);
        addRow(panel, "TotalTeamSize", teamSizeAndZeroDownlevelCount[0]);

        addRow(panel, "Are you Eligible DAO Delegator ", isdelegator);
        addRow(panel, "Are you Active DAO Delegator ", isdelegatorNode);
        const instAddr = node[3];
        const storAddr = node[4];
        addRow(panel, "INST---", "");
        addRow(panel, "InstAddr", node[3]);
        if (instAddr != "0x0000000000000000000000000000000000000000") {
            const inst = new web3.eth.Contract(IInstanceMeABI.abi, instAddr);
            const instId = await inst.methods.id().call();
            const instParent = await inst.methods.parent().call();
            const instStor = await inst.methods.stor().call();
            addRow(panel, "Instance ID", instId);
            addRow(panel, "Instance Parent", instParent);
            addRow(panel, "Instance Stor", instStor);
        }
        addRow(panel, "STOR---", "");
        addRow(panel, "StorAddr", node[4]);

        await loadMyStor(id, panel);
        await loadMyOldStorData(id);

        await loadMyNFT();
    } catch (err) {
        console.error(err);
        addRow(panel, "Error", "Unable to load marketplace");
    }

    hideLoader();


}


function formatRow(arr, width = 15) {
    return arr
        .map(v => String(v).padStart(width, " "))
        .join(' | ');
}
async function loadMyOldStorData(id) {

    nestedOld = new web3.eth.Contract(INested741ABI.abi, "0xa4cb3f45F46B3c31780D70568b0627b3339eB76d");
    const node = await nestedOld.methods.getNode(id).call();
    const storAddr = node[4];
    if (storAddr != "0x0000000000000000000000000000000000000000") {
        const stor = new web3.eth.Contract(IInstanceStorABI.abi, storAddr);
        const drawn = await stor.methods.getAllData(4, 0).call();
        console.log(`OLDLevel: ${drawn}`)
    }

    const userOldData = await transferRequests.methods.getUserOldData(currentAccount).call();
    console.log(`userOldData: ${userOldData}`)
}

async function loadMyStor(id, panel) {
    try {

        const node = await nested.methods.getNode(id).call();
        const storAddr = node[4];
        if (storAddr != "0x0000000000000000000000000000000000000000") {



            const stor = new web3.eth.Contract(IInstanceStorABI.abi, storAddr);
            const activedirectsCount = await stor.methods.activedirectsCount().call();
            const dage = await stor.methods.dage().call();
            const rankWithAge = await stor.methods.getRankWithAgeValue().call();
            const cage = await stor.methods.cage().call();
            const isLock = await stor.methods.isLock().call();
            const postInit = await stor.methods.postInit().call();
            addRow(panel, "Stor Active Directs", activedirectsCount);
            addRow(panel, "Stor Cage", `${getAgeDateRange(cage).start} {${cage}}`);
            addRow(panel, "Stor Dage", `${getAgeDateRange(dage).start} {${dage}}`);
            addRow(panel, "Stor Rank", `Rank: ${rankWithAge[0]}`);
            addRow(panel, "Stor postInit", `postInit: ${postInit}`);

            const tableRg = document.createElement("table");
            tableRg.border = "1";
            tableRg.cellPadding = "5";
            tableRg.style.width = "50%";
            tableRg.style.display = "table-cell";
            addRow(panel, "Rank ages", tableRg);
            // ✅ THEAD (Header)
            const theadRg = document.createElement("thead");
            theadRg.innerHTML = `
                <tr>
                    <th>Rank</th>
                    <th>Age</th>
                    <th>Date</th>
                </tr>
                `;
            tableRg.appendChild(theadRg);
            const tbodyRg = document.createElement("tbody");
            const getRankAgeInBatch = await stor.methods.getRankAgeInBatch().call();
            for (let r = 0; r < getRankAgeInBatch.length; r++) {
                const row = document.createElement("tr")
                row.innerHTML = `
                    <td>${parseInt(r)}</td>
                    <td>${getRankAgeInBatch[r]}</td>
                    <td>${getAgeDateRange(getRankAgeInBatch[r]).start}</td>
                `;
                tbodyRg.appendChild(row);
            }

            // ✅ Attach tbody
            tableRg.appendChild(tbodyRg);

            /*
           let aj1 = await stor.methods.comp(15,2).call();
           let aj2 = await stor.methods.comp(15,1).call();
           
           let aj3 = await stor.methods.comp(14,2).call();
           let aj4 = await stor.methods.comp(14,1).call();
          
         
           stor.methods.rankage(0).call(console.log);
           stor.methods.rankage(1).call(console.log);
           stor.methods.rankage(2).call(console.log);
           
           // Fetch LSB 1,3,30,93,95,603,695,696
           const lsbIndexes = [1, 3, 30, 93, 95, 603, 695, 696];
           for (const i of lsbIndexes) {
               const val = await stor.methods.LSB(i).call();
               addRow(panel, `Stor LSB(${i})`, val);
           }
           */



            // Drawn, Flushed, Unpaid, Compute
            const drawn = await stor.methods.getAllData(1, 0).call();

            const misc = await stor.methods.getAllData(2, 0).call();
            const consts = await stor.methods.getAllData(3, 0).call();


            let compute;
            try {
                compute = await stor.methods.getAllComputeData(maxintervals).call();
            } catch (err) {
                console.error("❌ compute() failed:", err.message);

                // Fallback → prevent UI break
                //compute = [undefined, undefined, undefined, undefined, undefined, undefined, undefined];
            }
            console.log(`compute: ` + compute);

            const incomeTypes = ["Reward", "Royali", "Self", "Yeild", "Validator", "Tour", "Gift"];

            const TVL = await stor.methods.TVL().call();
            const label = "TVL " + formatOZN(TVL);
            // Add a header row
            addRow(panel, label, formatRow(["Compute", "ComputeFlush", "Drawn"]));

            for (let i = 0; i < 7; i++) {
                const comp = formatOZN(compute[`p${i + 1}`]);
                const compFlush = formatOZN(compute[`f${i + 1}`]);
                const drwn = formatOZN(drawn[i]);

                const susCount = await stor.methods.getToggleAgeCount(i + 1).call();

                addRow(panel, `${incomeTypes[i]} (${parseInt(susCount) % 2 == 1 ? "F" : "T"})`,
                    formatRow([
                        String(comp),
                        String(compFlush),
                        String(drwn)
                    ])
                );
            }

            const tableuf = document.createElement("table");
            tableuf.border = "0";
            tableuf.cellPadding = "1";
            tableuf.style.width = "50%";
            tableuf.style.display = "table-cell";
            addRow(panel, "->", tableuf);
            // ✅ THEAD (Header)
            const theaduf = document.createElement("thead");
            theaduf.innerHTML = `
                <tr>
                    <th>TVL</th>
                    <th>Unpaid</th>
                    <th>Unpaid Self</th>
                    <th>Flushed</th>
                </tr>
                `;
            tableuf.appendChild(theaduf);

            const tbodyuf = document.createElement("tbody");
            const row = document.createElement("tr")
            row.innerHTML = `
                    <td>${formatOZN(TVL)}</td>
                    <td>${formatOZN(misc[0])}</td>
                    <td>${formatOZN(misc[1])}</td>
                    <td>${formatOZN(misc[2])}</td>
            `;

            tbodyuf.appendChild(row);

            // ✅ Attach tbody
            tableuf.appendChild(tbodyuf);



            const right = document.createElement("div");
            const btnClaim = document.createElement("button");
            btnClaim.innerText = "Claim";
            btnClaim.style.marginLeft = "10px";
            btnClaim.onclick = () => {
                onClaim();
            };

            const btnCapBurn = document.createElement("button");
            btnCapBurn.innerText = "CapBurn";
            btnCapBurn.style.marginLeft = "10px";

            btnCapBurn.onclick = () => {
                onCapBurn();
            };

            const btnTVLRefresh = document.createElement("button");
            btnTVLRefresh.innerText = "TVLRefresh";
            btnTVLRefresh.style.marginLeft = "10px";

            btnTVLRefresh.onclick = () => {
                onTVLRefresh();
            };

            const btnLoadBusiness = document.createElement("button");
            btnLoadBusiness.innerText = "LoadBusiness";
            btnLoadBusiness.style.marginLeft = "10px";
            btnLoadBusiness.onclick = () => {
                onLoadBusiness(storAddr);
            };

            right.appendChild(btnTVLRefresh);
            right.appendChild(btnClaim);
            right.appendChild(btnCapBurn);
            right.appendChild(btnLoadBusiness);

            addRow(panel, "->", right);

            const toggleAgeListdiv = document.createElement("div");
            toggleAgeListdiv.style.display = "-webkit-inline-box";
            toggleAgeListdiv.style.alignItems = "center";
            toggleAgeListdiv.style.gap = "8px";

            const guagecontainer = document.createElement("div");
            guagecontainer.id = "container";
            guagecontainer.style.width = "520px";

            const tableToggle = document.createElement("table");
            tableToggle.border = "1";
            tableToggle.cellPadding = "5";
            tableToggle.style.width = "50%";
            tableToggle.style.display = "table-cell";
            toggleAgeListdiv.appendChild(guagecontainer);
            toggleAgeListdiv.appendChild(tableToggle);
            addRow(panel, "ToggleAgeList", toggleAgeListdiv);
            // ✅ THEAD (Header)
            const theadToggle = document.createElement("thead");
            theadToggle.innerHTML = `
                <tr>
                    <th>Head</th>
                    <th>Count</th>
                    <th>ages</th>
                </tr>
                `;
            tableToggle.appendChild(theadToggle);
            const tbodyToggle = document.createElement("tbody");
            const values = [...Array.from({ length: 7 }, (_, i) => i + 1), 999];

            let actualCap = false;
            for (const v of values) {
                console.log(v);
                const susCount = await stor.methods.getToggleAgeCount(v).call();
                actualCap = susCount % 2 == 1;
                const result = [];
                for (let i = 0; i < susCount; i++) {
                    const value = await stor.methods.getToggleAgeValue(v, i).call();
                    result.push({
                        index: i,
                        value: value
                    });
                }

                const row = document.createElement("tr")
                row.innerHTML = `
                    <td>${v}</td>
                    <td>${susCount}</td>
                    <td>${result.map(item => `<div>${item.index} - ${item.value}</div>`).join("")}</td>
                `;
                tbodyToggle.appendChild(row);
            }


            // ✅ Attach tbody
            tableToggle.appendChild(tbodyToggle);

            /*loadGraph({
                totalIncome: formatOZN(capStatus.totalIncome),
                burned4x: formatOZN(capStatus.burnedx),
                threshold: formatOZN(capStatus.threshold),
                cap: capStatus._cap,
                currentValue:formatOZN(capStatus.currentValue)

            });*/


            const panelCompCap = addPanel("Compute Capping");

            const minpaydollartozonewei = await rule.methods.computeDollarToOzone(compute.minpaydollar.toString()).call();
            const minpaydollartozone = formatOZN(minpaydollartozonewei);

            const totincdollartozonewei = await rule.methods.computeDollarToOzone(compute.totIncdollar.toString()).call();
            const totincdollartozone = formatOZN(totincdollartozonewei);


            addRow(panelCompCap, "Compute CAP", compute.cap);

            const lvlBatch = await stor.methods.getNodeLvlInfoBatch(0, 0).call();

            addRow(panelCompCap, "$", formatRow([
                "Invested_Dollar",
                "Burned_Dollar",
                "Threshold_3X_Dollar",
                "TotalInc_Dollar",
                "Claimed_CAP_Dollar",
                "MinPay_Dollar",
                "CAP_STATUS"
            ]));

            addRow(panelCompCap, "..", formatRow([
                formatOZN(consts[1]),
                formatOZN(consts[5]),
                formatOZN(compute.thresholdollarx),
                formatOZN(compute.totIncdollar),
                formatOZN(consts[6]),
                parseFloat(formatOZN(compute.minpaydollar)),
                compute.capdollar
            ]));

            addRow(panelCompCap, "..", formatRow([
                " ",
                " ",
                " ",
                '(' + totincdollartozone + ')',
                " ",
                '(' + minpaydollartozone + ')',
                " "
            ]));

            addRow(panelCompCap, "OZ", formatRow([
                "TotalBusiness",
                "BURNED",
                "Threshold_3X",
                "TotalInc",
                "Claimed_CAP",
                "MinPay",
                "CAP_STATUS"
            ]));

            addRow(panelCompCap, "..", formatRow([
                formatOZN(consts[0]),
                formatOZN(consts[4]),
                formatOZN(compute.thresholdx),
                formatOZN(compute.totInc),
                formatOZN(misc[6]),
                parseFloat(formatOZN(compute.minpay)),
                compute.capinc
            ]));

            // Burned & Self Proposed
            //CALC_SELF_PROPOSED, CALC_SELF_FLUSH_PROPOSED, inc[_RWRD_IX_].old, inc[_YEILD_IX_].old
            //BURNED, BURNED_DOLLAR, INVESTED_DOLLAR, CLAIMED_DOLLAR, 0, 0, 0

            addRow(panel, "ACTUAL CAPPING", actualCap.toString().toUpperCase());
            addRow(panel, "CALC_SELF_PROPOSED", formatOZN(misc[2]));
            addRow(panel, "CALC_SELF_FLUSH_PROPOSED", formatOZN(misc[3]));
            addRow(panel, "OLD_RWRD", formatOZN(misc[4]));
            addRow(panel, "OLD_YEILD", formatOZN(misc[5]));
            addRow(panel, "LOCKED", isLock);


        }
    } catch (err) {

        console.error(err);
        addRow(panel, "Error", "Unable to load store");

    }
}

async function loadUpline() {
    showLoader();
    const input = document.getElementById("userAddrInput");
    const user = input.value.trim();
    if (!user || !web3.utils.isAddress(user)) {
        alert("Enter a valid Ethereum address");
        return;
    }
    clearPanels();

    try {

        const id = await nested.methods.UserToId(user).call();
        _loadUpline(id);

    } catch (err) {
        console.error(err);
        alert("loadUpline failed: " + (err.message || err));
    }

    hideLoader();

}


async function _loadUpline(id) {
    try {

        const node = await nested.methods.getNode(id).call();
        const panel = addPanel(`${node[0]} | ${node[1]} | ${node[2]}`);
        await loadMyStor(id, panel);
        if (parseInt(node[2]) > 0) await _loadUpline(parseInt(node[2]));

    } catch (err) {
        console.error(err);
        alert("loadUpline failed: " + (err.message || err));
    }
}


async function loadDAO() {
    clearPanels();
    const panel = addPanel("DAO Admin");
    try {


        addRow(panel, "DAO Core", indaocore);
        addRow(panel, "DAO Assembly", indaoassembly);

        const delegatorCount = await daoassembly.methods.getdelegatorCount().call();

        const rankforDAO = await rule.methods.rankforDAO().call();

        // const blacklistedCount = await daoassembly.methods.blacklistedCount().call();
        const proposalsCount = await daocore.methods.getProposalsCount().call();
        const templateCount = await daocore.methods.templateCount().call();
        const left = document.createElement("div");

        left.innerHTML =
            '<div style="display:flex;align-items:center;gap:8px;">'
            + ' DelegatorCount: ' + delegatorCount
            + ' | RankForDAO: ' + rankforDAO
            + ' | BlacklistedCount: ' + 0
            //+ ' | ProposalsCount: ' + proposalsCount    
            + '</div>';

        const left2 = document.createElement("div");
        const right2 = document.createElement("div");

        /*
         const btnChangeParent = document.createElement("button");
         btnChangeParent.innerText = "ChangeParent";
         btnChangeParent.style.marginLeft = "10px";
         btnChangeParent.onclick = () => {
             onChangeParent();
         };
 
         const btnChangeOwner = document.createElement("button");
         btnChangeOwner.innerText = "ChangeOwner";
         btnChangeOwner.style.marginLeft = "10px";
         btnChangeOwner.onclick = () => {
             onChangeOwner();
         };
 
         const btnSuspendIncome = document.createElement("button");
         btnSuspendIncome.innerText = "SuspendIncome";
         btnSuspendIncome.style.marginLeft = "10px";
         btnSuspendIncome.onclick = () => {
             onSuspendIncome();
         };
 
         const btnLockUser = document.createElement("button");
         btnLockUser.innerText = "LockUser";
         btnLockUser.style.marginLeft = "10px";
         btnLockUser.onclick = () => {
             onLockuser();
         };
 
         const btnSecureBase = document.createElement("button");
         btnSecureBase.innerText = "Securebase";
         btnSecureBase.style.marginLeft = "10px";
         btnSecureBase.onclick = () => {
             onSecureBase();
         };
 
         
 
 
         left2.appendChild(btnChangeParent);
         left2.appendChild(btnChangeOwner);
         left2.appendChild(btnSuspendIncome);
         left2.appendChild(btnLockUser);
         left2.appendChild(btnSecureBase);
         */

        const btnCreateTemplate = document.createElement("button");
        btnCreateTemplate.innerText = "CreateTemplate";
        btnCreateTemplate.style.marginLeft = "10px";
        btnCreateTemplate.onclick = () => {
            const tid = prompt("Enter template id:");
            onCreateTemplate(parseInt(tid));
        };
        const btnTemplates = document.createElement("button");
        btnTemplates.innerText = "AllTemplates";
        btnTemplates.style.marginLeft = "10px";
        btnTemplates.onclick = () => {
            loadTemplates();
        };

        left2.appendChild(btnCreateTemplate);
        left2.appendChild(btnTemplates);

        const btnTransferForms = document.createElement("button");
        btnTransferForms.innerText = "TransferForms";
        btnTransferForms.style.marginLeft = "10px";
        btnTransferForms.onclick = () => {
            loadTransferForms();
        };

        const btnProposals = document.createElement("button");
        btnProposals.innerText = "Proposals";
        btnProposals.style.marginLeft = "10px";
        btnProposals.onclick = () => {
            loadProposals();
        };



        right2.appendChild(btnTransferForms);
        right2.appendChild(btnProposals);

        addRow(panel, left, "");
        addRow(panel, 'TemplateCount: ' + templateCount, 'ProposalsCount: ' + proposalsCount);
        addRow(panel, left2, right2);
    } catch (err) {
        console.error(err);
        addRow(panel, "", err.message);
    }
    hideLoader();
}

function addProposal(tid) {
    var templateid = parseInt(tid);
    if (templateid == 1) onChangeParent();
    else if (templateid == 2) onChangeOwner();
    else if (templateid == 3) onSuspendIncome();
    else if (templateid == 4) onLockuser();
    else if (templateid == 5) onClaimperday();
    else if (templateid == 6) onSecureBase();
    else if (templateid == 7) onDAOWinPer();
    else if (templateid == 8) onDAOBlacklist();
    else alert('invalid template');
}

/*
DATA_SUCCESS=$(cast calldata "safeSecureBaseCallback(address,bool)" $SECUREBASE true)
TARGET="$safeguardPrime"
VALUE_SUCCESS="0"
echo "Encoded success calldata: $DATA_SUCCESS"
SUBJECT="Trigger.securebase.proposal.UpdateBonusRequestsPrime"
echo "$SUBJECT"
#send "$PKKEY" "$DAOAssemblyCore" "0" "newProposal(string,address,uint256,bytes,uint256)" "$SUBJECT" "$TARGET" "$VALUE_SUCCESS" "$DATA_SUCCESS" "7" 
*/
//function setMoveDownlineApproval(uint256 _id, address parent, bool approval)
async function onChangeOwner() {
    try {

        const olduseraddress = prompt("Enter old User id needs to be changed");

        if (olduseraddress !== null && olduseraddress !== "") {
            if (!nested.method.isUserExists(olduseraddress)) { alert('incorrect address'); return }
        } else {
            alert("No User address entered");
            return;
        }

        const newuseraddress = prompt("Enter new User id needs to be update");

        if (newuseraddress !== null && newuseraddress !== "") {
            if (nested.method.isUserExists(newuseraddress)) { alert('already exists'); return }
        } else {
            alert("No User address entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["address", "address"],
            [olduseraddress, newuseraddress]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(2, ZERO, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("NewProposer succeeded");
        } else {
            alert("NewProposer failed");
        }


    } catch (err) {
        console.error(err);
        alert("NewProposer failed: " + (err.message || err));
    }
}

async function onChangeParent() {
    try {

        const userId = prompt("Enter User id needs to be moved:");

        if (userId !== null && userId !== "") {
            if (!nested.method.isNode(userId)) { alert('incorrect id'); return }
        } else {
            alert("No User ID entered");
            return;
        }

        const parentId = prompt("Enter parent id needs to be switched:");

        if (parentId !== null && parentId !== "") {
            if (!nested.method.isNode(parentId)) { alert('incorrect id'); return }
        } else {
            alert("No Parent ID entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["uint256", "uint256"],
            [userId, parentId]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(1, ZERO, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("NewProposer succeeded");
        } else {
            alert("NewProposer failed");
        }


    } catch (err) {
        console.error(err);
        alert("NewProposer failed: " + (err.message || err));
    }
}

async function onSuspendIncome() {
    try {

        const userId = prompt("Enter User id needs to be suspend:");

        if (userId !== null && userId !== "") {
            if (!nested.method.isNode(userId)) { alert('incorrect id'); return }
        } else {
            alert("No User ID entered");
            return;
        }

        const incomekey = prompt("Enter Income key:");

        if (incomekey !== null && incomekey !== "") {
            if (parseInt(incomekey) >= 1 && parseInt(incomekey) <= 7) { alert('incorrect key'); return }
        } else {
            alert("No key entered");
            return;
        }


        const startstop = prompt("Type- 1:stop | 0:start");

        if (startstop !== null && startstop !== "") {
            if (!(parseInt(startstop) >= 0 && parseInt(startstop) <= 1)) { alert('incorrect startstop'); return }
        } else {
            alert("No startstop entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["uint256", "bool"],
            [incomekey, parseInt(startstop) == 1]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        const useraddress = nested.methods.nodes(userId);
        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(3, useraddress, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("NewProposer succeeded");
        } else {
            alert("NewProposer failed");
        }


    } catch (err) {
        console.error(err);
        alert("NewProposer failed: " + (err.message || err));
    }
}

async function onSecureBase() {
    try {

        const base = prompt("Enter base address needs to be add/remove:");

        if (base == null && base == "") {
            alert("No Base entered");
            return;
        }

        const addremove = prompt("Type- (1:add) | (0:remove) ");

        if (addremove !== null && addremove !== "") {
            if (!(parseInt(addremove) >= 0 && parseInt(addremove) <= 1)) { alert('incorrect addremove'); return; }
        } else {
            alert("No type entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["address", "bool"],
            [base, parseInt(addremove) == 1]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(6, ZERO, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("NewProposer succeeded");
        } else {
            alert("NewProposer failed");
        }


    } catch (err) {
        console.error(err);
        alert("NewProposer failed: " + (err.message || err));
    }
}

async function onDAOWinPer() {
    try {

        const winper = prompt("Type- Wining percent");

        if (winper !== null && winper !== "") {
            if (!(parseInt(winper) >= 0)) { alert('incorrect Wining percent'); return; }
        } else {
            alert("No winper entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["uint256"],
            [parseInt(winper)]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(7, ZERO, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("DAO WinPer succeeded");
        } else {
            alert("DAO WinPer failed");
        }


    } catch (err) {
        console.error(err);
        alert("DAO WinPer  failed: " + (err.message || err));
    }
}

async function onDAOBlacklist() {
    try {

        const base = prompt("Enter DAO address needs to be whitelist/blacklist:");

        if (base == null && base == "") {
            alert("No Base entered");
            return;
        }

        const addremove = prompt("Type- (1:blacklist) | (0:whitelist) ");

        if (addremove !== null && addremove !== "") {
            if (!(parseInt(addremove) >= 0 && parseInt(addremove) <= 1)) { alert('incorrect Type'); return; }
        } else {
            alert("No Type entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["address", "bool"],
            [base, parseInt(addremove) == 1]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(8, ZERO, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("DAOBlacklist succeeded");
        } else {
            alert("DAOBlacklist failed");
        }


    } catch (err) {
        console.error(err);
        alert("DAOBlacklist failed: " + (err.message || err));
    }
}

async function onLockuser() {
    try {

        const userId = prompt("Enter User id needs to be locked:");

        if (userId !== null && userId !== "") {
            if (!nested.method.isNode(userId)) { alert('incorrect id'); return }
        } else {
            alert("No User ID entered");
            return;
        }

        const startstop = prompt("Type- 1:lock | 0:unlocked");

        if (startstop !== null && startstop !== "") {
            if (parseInt(startstop) >= 0 && parseInt(startstop) <= 1) { alert('incorrect lock'); return }
        } else {
            alert("No lock entered");
            return;
        }

        const params = web3.eth.abi.encodeParameters(
            ["bool"],
            [startstop == 1]
        );

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);
        const useraddress = nested.methods.nodes(userId);
        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        // prepare method
        const method = daoContract.methods.newProposal(4, useraddress, params, 0);

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("NewProposer succeeded");
        } else {
            alert("NewProposer failed");
        }


    } catch (err) {
        console.error(err);
        alert("NewProposer failed: " + (err.message || err));
    }
}

async function onMovedownlineProposer(uid) {

    try {


        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const nestedContractT = new web3T.eth.Contract(INested741ABI.abi, inNested741);

        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        // estimate gas
        const gas = 9999999;

        // send transaction
        const receipt = await nestedContractT.methods
            .moveDownline(uid)
            .send({
                from: currentAccount,
                value: "0",

                gas: Math.floor(gas * 1.1), // small buffer

                maxPriorityFeePerGas: "1", // low tip
                maxFeePerGas: (baseFee + 2n).toString() // just above base fee
            });

        if (receipt.status) {
            alert("Movedownline succeeded");
        } else {
            alert("Movedownline failed");
        }
    } catch (err) {
        console.error(err);
        alert("Movedownline failed: " + (err.message || err));
    }
}
//send "$PKKEY" "$TransferRequest" "0" "submitTransferForm(address,address[] memory)" "$ADDRESS" "$mandatedvoters_arr"

async function onSubmitTrasfer() {

    try {

        const fromAddress = prompt("Enter ADDRESS to be transferred:");
        if (!fromAddress) {
            throw 'Enter from Address';
        }
        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const trContract = new web3T.eth.Contract(ITransferRequestsABI.abi, inproposals[0]);

        const tx = await trContract.methods
            .submitTransferForm(fromAddress, 10)
            .send({
                from: currentAccount,
                value: 0 // change if initialization requires ETH
            });

        if (tx.status) {
            alert("SubmitTrasfer succeeded");
        } else {
            alert("SubmitTrasfer failed");
        }


    } catch (err) {
        console.error(err);
        alert("SubmitTrasfer failed: " + (err.message || err));
    }

}

/*

    struct ProposalTemplate {
        string desc;
        address target;
        bytes4 selector;
        bool active;
        uint256 deadline;
        uint256 callType; //0-system.1-userinstance,2-userstor
    }

    mapping(uint256 => ProposalTemplate)
        public proposalTemplates;

    uint256 public ;
 * 
*/
async function loadTemplates() {
    const panel = addPanel("Templates");
    try {
        const count = await daocore.methods.templateCount().call();
        const table = document.createElement("table");
        table.border = "1";
        table.cellPadding = "5";
        table.style.width = "100%";
        // ✅ THEAD (Header)
        const thead = document.createElement("thead");
        thead.innerHTML = `
        <tr>
            <th>#</th>
            <th>Desc</th>
            <th>Target</th>
            <th>Selector</th>
            <th>Active</th>
            <th>Deadline</th>
            <th>CallType</th>
            <th>Add</th>
            <th>Cancel</th>
        </tr>
        `;
        table.appendChild(thead);
        const tbody = document.createElement("tbody");
        for (let i = 0; i < count; i++) {

            const p = await daocore.methods.proposalTemplates(i).call();

            const row = document.createElement("tr");

            row.innerHTML = `
                    <td>${i + 1}</td>
                    <td title="${p.desc}">${p.desc}</td>
                    <td class="shortAddr" title="${p.target}">${shortAddr(p.target)}</td>
                    
                    <td class="shortAddr paramsCell">${p.selector}</td>
                    <td>${p.active}</td>
                    <td>${p.deadline}</td>
                    <td>${p.callType}</td>
                    <td class="shortAddr paramsCell">
                        <button class="vote-btn" onclick="addProposal(${i + 1})">Add proposal</button>
                    </td>
                    <td class="shortAddr paramsCell">
                        <button class="vote-btn" onclick="canceltemplate(${i + 1})">Cancel</button>
                    </td>
                `;

            tbody.appendChild(row);
        }

        // ✅ Attach tbody
        table.appendChild(tbody);

        addRow(panel, "", table);
    } catch (err) {
        console.error(err);
        addRow(panel, "", err.message);
    }
}

async function loadProposals() {
    const panel = addPanel("Proposals");
    try {
        const count = await daocore.methods.getProposalsCount().call();

        let limit = 3;

        const table = document.createElement("table");
        table.border = "1";
        table.cellPadding = "5";
        table.style.width = "100%";
        // ✅ THEAD (Header)
        const thead = document.createElement("thead");
        thead.innerHTML = `
        <tr>
            <th>#</th>
            <th>Desc</th>
            <th>Target</th>
            <th>Up</th>
            <th>Dn</th>
            <th>Win</th>
            <th>Status</th>
            <th>Resolved</th>
            <th>params</th>
            <th>Vote</th>
            <th>Sign</th>
        </tr>
        `;
        table.appendChild(thead);
        const tbody = document.createElement("tbody");
        for (let i = count; i >= 1 && limit > 0; i--) {

            const p = await daocore.methods.getProposal(i).call();
            const r = await daocore.methods.getResult(i).call();
            let approve = "PENDING"
            if (r[5]) approve = "RESOLVE";

            const row = document.createElement("tr");
            row.innerHTML = `
          <td>${i}</td>
          <td title="${p[0]}">${p[0]}</td>
          <td class="shortAddr " title="${p[1]}">${shortAddr(p[1])}</td>
          
          <td>${r[0]}</td>
          <td>${r[1]}</td>
          <td>${r[3]}</td>
          <td>${r[4]}</td>
          <td>${approve}</td>
          <td class="shortAddr paramsCell" title="${p[5]}">${p[6]}</td>
          <td >
            <button class="vote-btn upvote" onclick="vote(${i}, true)">Vote(Y)</button>
            <button class="vote-btn downvote" onclick="vote(${i}, false)">Vote(N)</button>
          </td>
          <td>
            <button onclick="cancelproposal(${i})">Cancel</button>
          </td>
        `;
            tbody.appendChild(row);
            limit--;
        }

        // ✅ Attach tbody
        table.appendChild(tbody);



        addRow(panel, "", table);
    } catch (err) {
        console.error(err);
        addRow(panel, "", err.message);
    }
}

async function loadTransferForms() {

    const panel = addPanel("TransferForms");
    try {
        const count = await transferRequests.methods.getFormsCount().call();

        let limit = 10;
        const table = document.createElement("table");
        table.border = "1";
        table.cellPadding = "5";
        table.style.width = "100%";
        // ✅ THEAD (Header)
        const thead = document.createElement("thead");
        thead.innerHTML = `
        <tr>
            <th>#</th>
            <th>from</th>
            <th>to</th>
            <th>resolved</th>
            <th>closed</th>
            <th>status</th>
            <th>proposalId</th>
            <td>Close Action</td>
        </tr>
        `;
        table.appendChild(thead);
        const tbody = document.createElement("tbody");
        for (let i = count; i >= 1 && limit > 0; i--) {

            const p = await transferRequests.methods.getForm(i).call();

            const row = document.createElement("tr");
            row.innerHTML = `
          <td>${i}</td>
          <td class="shortAddr" title="${p[p.from]}">${shortAddr(p.from)}</td>
          <td class="shortAddr" title="${p[p.to]}">${shortAddr(p.to)}</td>
          <td>${p.resolved}</td>
          <td>${p.closed}</td>
          <td>${p.status}</td>
          <td>${p.proposalId}</td>
          <td>
            <button class="vote-btn upvote" onclick="closeTransferTarget('${p.to}')">Close</button>
          </td>

        `;
            tbody.appendChild(row);
            limit--;
        }

        // ✅ Attach tbody
        table.appendChild(tbody);



        addRow(panel, "", table);
    } catch (err) {
        console.error(err);
        addRow(panel, "", err.message);
    }
}
async function closeTransferTarget(to) {
    try {
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const transferContract = new web3T.eth.Contract(ITransferRequestsABI.abi, inproposals[0]);

        const tx = await transferContract.methods.closeTransferTarget(to).send({ from: accounts[0] });
        if (tx.status) {
            alert("Transfer Closed succeeded");
        }
        else {
            alert("Transfer Closed failed");
        }
    } catch (err) {
        console.error(err);
        alert("❌ Transfer Closed failed: " + (err.message || err));
    }
}

async function vote(proposalId, support) {
    try {
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        const tx = await daoContract.methods.vote(proposalId, support).send({ from: accounts[0] });
        if (tx.status) {
            alert("vote succeeded");
        }
        else {
            alert("vote failed");
        }
    } catch (err) {
        console.error(err);
        alert("❌ Vote failed: " + (err.message || err));
    }
}

async function execute(proposalId, isapproved) {
    try {
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const daoContract = new web3T.eth.Contract(IDAOCoreABI.abi, indaocore);

        const tx = await daoContract.methods.execute(proposalId, isapproved).send({ from: accounts[0] });
        if (tx.status) {
            alert("execute succeeded");
        }
        else {
            alert("execute failed");
        }
    } catch (err) {
        console.error(err);
        alert("❌ execute failed: " + (err.message || err));
    }
}


async function loadMarket() {

    clearPanels();
    const panelMarket = addPanel("Marketplace");

    try {

        const o1155 = await hexBase.methods.inOrc1155(2).call();
        const orc1155 = new web3.eth.Contract(IORC1155ABI.abi, o1155);

        addRow(panelMarket, "Contract", o1155);

        const name = await orc1155.methods.name().call();
        const curSupply = await orc1155.methods.curSupply().call();
        const totSupply = await orc1155.methods.totSupply().call();
        const nftprice = await rule.methods.computeMintValue(1).call();

        addRow(panelMarket, "Collection", name);
        addRow(panelMarket, "Total Supply", totSupply);
        addRow(panelMarket, "Minted", curSupply);
        addRow(panelMarket, "Price", formatOZN(nftprice) + " / unit");
        const nftRows = [];

        let i = 1;
        let flag = true;

        while (flag) {

            try {

                const tokenName = await orc1155.methods.names(i - 1).call();

                if (!tokenName) {
                    flag = false;
                    break;
                }

                const metadataURI = await orc1155.methods.uri(i).call();
                const meta = await fetch(metadataURI).then(r => r.json());

                const row = document.createElement("div");
                row.className = "row";

                const left = document.createElement("div");
                left.innerHTML =
                    '<div style="display:flex;align-items:center;gap:8px;">'
                    + '<img src="' + meta.image + '" width="40" height="40">'
                    + '<span>#' + i + ' ' + tokenName + '</span>'
                    + '</div>';

                const right = document.createElement("div");

                if (currentAccount) {

                    const btn = document.createElement("button");
                    btn.innerText = "Buy";
                    btn.style.padding = "4px 8px";

                    const tokenId = i;   // capture correct id
                    btn.onclick = () => buyNFT(o1155, tokenId);

                    right.appendChild(btn);

                } else {

                    right.innerText = "Connect wallet";

                }

                row.appendChild(left);
                row.appendChild(right);
                nftRows.push(row);
                //panelNFT.appendChild(row);

                i++;

            } catch (e) {
                flag = false;
            }

        }

        addRow(panelMarket, "Total NFT Tokens", i);
        const panelNFT = addPanel("NFT Marketplace");
        nftRows.slice(0, 3).forEach(r => panelNFT.appendChild(r));



    } catch (err) {

        console.error(err);
        addRow(panelMarket, "Error", "Unable to load marketplace");

    }

    hideLoader();
}

async function loadMyNFT() {

    //clearPanels();
    const input = document.getElementById("userAddrInput");
    const user = input.value.trim();

    if (!user || !web3.utils.isAddress(user)) {
        alert("Enter a valid address");
        return;
    }

    const id = await nested.methods.UserToId(user).call();
    const node = await nested.methods.getNode(id).call();
    const instance = node[3];
    const stor = node[4];

    const panel = addPanel("My Minted NFTs");

    if (!stor || stor == ZERO) {
        addRow(panel, "User", "Instance/Stor not found");
        return;
    }

    const storeContract = new web3.eth.Contract(IInstanceStorABI.abi, stor);
    const mintCount = await storeContract.methods.mintCount().call();
    const currentLSBversion = await storeContract.methods.currentLSBversion().call();

    const currentCycle = 0;  //await storeContract.methods.currentCycle().call();
    const userCycleMintCount = await storeContract.methods.userCycleMintCount(currentCycle).call();


    const lsbpanel = addPanel("LSB Amount");
    let lsbindex = await storeContract.methods.withdrawlDage().call();
    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `WithdrawlDage: ${getAgeDateRange(lsbindex).start} {${lsbindex}}`
    }));

    lsbindex = await storeContract.methods.dage().call();
    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `Dage: ${getAgeDateRange(lsbindex).start} {${lsbindex}}`
    }));
    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `Dage LSB[${parseInt(lsbindex)}]: ${web3.utils.fromWei(await storeContract.methods.LSB(currentLSBversion, parseInt(lsbindex)).call(), "ether")}`
    }));

    lsbindex = parseInt(lsbindex) + 1;

    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `Dage: ${getAgeDateRange(lsbindex).start} {${lsbindex}}`
    }));
    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `Dage LSB[${parseInt(lsbindex)}]: ${web3.utils.fromWei(await storeContract.methods.LSB(currentLSBversion, parseInt(lsbindex)).call(), "ether")}`
    }));

    lsbindex = parseInt(lsbindex) + 1;

    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `Dage: ${getAgeDateRange(lsbindex).start} {${lsbindex}}`
    }));
    lsbpanel.appendChild(Object.assign(document.createElement("div"), {
        className: "row",
        innerHTML: `Dage LSB[${parseInt(lsbindex)}]: ${web3.utils.fromWei(await storeContract.methods.LSB(currentLSBversion, parseInt(lsbindex)).call(), "ether")}`
    }));


    let mintid = 0;
    if (parseInt(mintCount) == 0) mintid = 0;

    const mintspan = document.createElement("span");
    mintspan.id = "mintspan";
    mintspan.innerText = mintid + " / " + mintCount;
    mintspan.innerText = "userCycleMintCount[" + currentCycle + "]: " + userCycleMintCount + " Mints: " + mintid + " / " + mintCount;

    const btnMintLoad = document.createElement("button");
    btnMintLoad.innerText = "Load Mints";
    btnMintLoad.style.marginLeft = "10px";
    btnMintLoad.onclick = () => {
        if (parseInt(mintCount) > 0) {
            document.getElementById("mintspan").innerText = "Loading mint...";
            mintid++;
            onMintLoad();
        }
    };
    addRow(panel, btnMintLoad, mintspan);
    async function onMintLoad() {

        if (mintid > parseInt(mintCount) || parseInt(mintCount) == 0) return;

        const mint = await storeContract.methods.mints(mintid).call();
        const nftAddr = mint.nft;

        const nft = new web3.eth.Contract(IORC1155ABI.abi, nftAddr);

        const mintedUser = await nft.methods.mintedUser().call();

        if (mintedUser.toLowerCase() !== user.toLowerCase()) return;


        const tokenId = await nft.methods.ids(0).call();
        const tokenName = await nft.methods.names(0).call();

        const mintedqty = await nft.methods.mintedqty().call();
        const mintedfee = await nft.methods.mintedfee().call();
        const mintedAge = await nft.methods.mintedAge().call();
        const clonedOf = await nft.methods.clonedOf().call();
        const balance = await nft.methods.balanceOf(user, tokenId).call();
        const getNftPool = await rule.methods.getNftPool(1, mintedAge).call();

        const jsunlocked = await getUnlockedNFT(parseInt(mintedAge), parseInt(mintedqty));
        ;
        const unlocked = await nft.methods.getUnlockedNFT().call();
        const claimed = await nft.methods.claimed().call();

        const startfrom = getNftPool._startfrom;

        const uri = await nft.methods.uri(tokenId).call();
        const meta = await fetch(uri).then(r => r.json());

        const row = document.createElement("div");
        row.className = "row";

        const left = document.createElement("div");

        const rowTop = document.createElement("div");
        rowTop.style.display = "flex";
        rowTop.style.alignItems = "center";
        rowTop.style.gap = "8px";

        const idSpan = document.createElement("span");
        idSpan.innerText = tokenId;

        const img = document.createElement("img");
        img.src = meta.image;
        img.width = 40;
        img.height = 40;

        rowTop.appendChild(idSpan);
        rowTop.appendChild(img);

        const nftaddrdivMain = document.createElement("div");
        nftaddrdivMain.style.display = "";
        nftaddrdivMain.style.alignItems = "center";
        nftaddrdivMain.style.gap = "8px";


        const nftaddrdiv = document.createElement("div");
        nftaddrdiv.style.display = "flex";
        nftaddrdiv.style.alignItems = "center";
        nftaddrdiv.style.gap = "8px";

        const ageText = document.createElement("span");
        ageText.innerText = " | Age: " + mintedAge;
        nftaddrdiv.appendChild(renderAddress(nftAddr));
        nftaddrdiv.appendChild(ageText);


        const nftaddrdiv1 = document.createElement("div");
        nftaddrdiv1.style.display = "flex";
        nftaddrdiv1.style.alignItems = "center";
        nftaddrdiv1.style.gap = "8px";
        const idText = document.createElement("span");
        idText.innerText = ' CLONNED_OF ';
        nftaddrdiv1.appendChild(idText);
        nftaddrdiv1.appendChild(renderAddress(clonedOf));

        nftaddrdivMain.appendChild(nftaddrdiv);
        nftaddrdivMain.appendChild(nftaddrdiv1);

        rowTop.appendChild(nftaddrdivMain);

        left.appendChild(rowTop);
        const right = document.createElement("div");
        right.innerHTML =
            "Balance: " + balance +
            " | Fee: " + Number(web3.utils.fromWei(mintedfee, "ether")).toFixed(3) +
            " | Minted : " + mintedqty +
            " | Unlocked: " + unlocked +
            " | Claimed: " + claimed +
            " | startAge: " + startfrom + "";

        //" | Age: "+ `${getAgeDateRange(mintedAge).start} {${mintedAge}}`+" ";
        /* CHECKBOX */

        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.style.marginRight = "10px";

        /* TRANSFER BUTTON */

        const btnTransfer = document.createElement("button");
        btnTransfer.innerText = "Transfer";
        btnTransfer.style.marginLeft = "10px";


        btnTransfer.onclick = () => {
            onNFTTransfer(user, nftAddr, tokenId, checkbox.checked);
        };

        right.appendChild(checkbox);
        right.appendChild(btnTransfer);

        row.appendChild(left);
        row.appendChild(right);

        panel.appendChild(row);


        lsbpanel.appendChild(Object.assign(document.createElement("div"), {
            className: "row",
            innerHTML: `Mint LSB[${parseInt(mintedAge) + 2}]: ${web3.utils.fromWei(await storeContract.methods.LSB(currentLSBversion, parseInt(mintedAge) + 2).call(), "ether")}`
        }));
        lsbpanel.appendChild(Object.assign(document.createElement("div"), {
            className: "row",
            innerHTML: `Mint LSB[${parseInt(mintedAge) + 2 + 600}]: ${web3.utils.fromWei(await storeContract.methods.LSB(currentLSBversion, parseInt(mintedAge) + 2 + 600).call(), "ether")}`
        }));

        const currentCycle = 0;
        const userCycleMintCount = await storeContract.methods.userCycleMintCount(currentCycle).call();

        document.getElementById("mintspan").innerText = "userCycleMintCount[" + currentCycle + "]: " + userCycleMintCount + " Mints: " + mintid + " / " + mintCount;
    }



    /*;
    for(let i=0; i<=15; i++){
        
        const lvl = await storeContract.methods.getNodeLB(i).call();
        addRow(levelpanel, "Level ["+i+"]", ` ${formatOZN(lvl[0])} | ${lvl[1]} | ${formatOZN(lvl[2])} | ${formatOZN(lvl[3])} `);
    }*/




    hideLoader();
}

async function onLoadBusiness(storAdd) {
    showLoader();
    try {
        removePanelIfExists("Level Business");
        const levelpanel = addPanel("Level Business");

        const storeContract = new web3.eth.Contract(IInstanceStorABI.abi, storAdd);
        const lvlBatch = await storeContract.methods.getNodeLvlInfoBatch(0, 15).call();

        addRow(levelpanel, "Level ", ` Business | Qty | Reward | Yeild `);

        for (let i = 0; i <= 15; i++) {
            const lvl = lvlBatch[i];
            addRow(levelpanel, "Level [" + i + "]", ` ${formatOZN(lvl[0])} | ${lvl[1]} | ${formatOZN(lvl[2])} | ${formatOZN(lvl[3])} `);
        }

        const getMD = await nested.methods.getMoveDownline(id).call();

        const caption = getMD.op ? "Attach" : "Detach";

        const btnMovedownlineProposer = document.createElement("button");
        btnMovedownlineProposer.innerText = "Movedownline" + caption;
        btnMovedownlineProposer.style.marginLeft = "10px";
        btnMovedownlineProposer.style.display = getMD.exist ? "block" : "none";
        btnMovedownlineProposer.onclick = () => {
            onMovedownlineProposer(id);
        };

        addRow(levelpanel, "--", btnMovedownlineProposer);
    }
    catch {

    }
    hideLoader();

}

async function getUnlockedNFT(mintedAge, mintedqty) {
    const ONE = 1e18;
    sysAge = await nested.methods.systemAge().call();
    document.getElementById("sysAgeid").innerHTML = sysAge;
    // if shutdown()
    const system = await rule.methods.system().call();
    const isShutdown = system.shutdown;
    if (isShutdown) {
        return mintedqty;
    }

    let totalNFT = 0;

    const processPool = async (poolId) => {
        const pool = await rule.methods.getNftPool(poolId, mintedAge).call();

        let startfrom = Number(pool._startfrom);
        let roiN = Number(pool._roiN);
        let roiD = Number(pool._roiD);
        let roiInt = Number(pool._roiInt);

        if (sysAge < (mintedAge + startfrom)) {
            return 0;
        }

        if (roiInt > 0) {
            let cycles = Math.floor((sysAge - (mintedAge + startfrom)) / roiInt);

            if (cycles > 0) {
                return (mintedqty * ONE * roiN / (100 * roiD)) * cycles;
            }
        }

        return 0;
    };

    totalNFT += await processPool(1);
    totalNFT += await processPool(2);

    // normalize
    totalNFT = totalNFT / ONE;

    // cap
    if (totalNFT > mintedqty) {
        totalNFT = mintedqty;
    }

    return parseInt(totalNFT);
}

async function findAgeWhenNFTExceedsOne(rule, mintedAge, mintedqty, maxLookahead = 5000) {
    const ONE = 1e18;

    const system = await rule.methods.system().call();
    const isShutdown = system.shutdown;
    if (isShutdown) return null;

    const processPool = (ag, pool) => {
        let startfrom = Number(pool.startfrom);
        let roiN = Number(pool.roiN);
        let roiD = Number(pool.roiD);
        let roiInt = Number(pool.roiInt);

        if (ag < (mintedAge + startfrom)) return 0;

        if (roiInt > 0) {
            let cycles = Math.floor((ag - (mintedAge + startfrom)) / roiInt);

            if (cycles > 0) {
                return (mintedqty * ONE * roiN / (100 * roiD)) * cycles;
            }
        }
        return 0;
    };

    for (let ag = mintedAge; ag < mintedAge + maxLookahead; ag++) {

        const pool1 = await rule.methods.getNftPool(1, mintedAge).call();
        const pool2 = await rule.methods.getNftPool(2, mintedAge).call();

        let totalNFT =
            processPool(ag, pool1) +
            processPool(ag, pool2);

        totalNFT = totalNFT / ONE;

        if (totalNFT > 1) {
            return {
                age: ag,
                nft: totalNFT
            };
        }
    }

    return null;
}

async function validateLogin() {
    const instan = new web3.eth.Contract(IInstanceMeABI.abi, currentInstance);
    if (!(await instan.methods.validateToken().call())) throw "Login required";
}

async function onTVLRefresh() {
    showLoader();

    try {
        // Prompt for recipient
        const input = document.getElementById("userAddrInput");
        const user = input.value.trim();

        if (!user || !web3.utils.isAddress(user)) {
            alert("Enter a valid address");
            return;
        }

        const id = await nested.methods.UserToId(user).call();

        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (user.trim().toLowerCase() !== accounts[0].toLowerCase()) {
            throw "Incorrect account selected";
        }
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        // Enable wallet
        // const nestedContractV1 = new web3T.eth.Contract(INested741ABI.abi, inNested741);

        const Nested741TVLContract = new web3T.eth.Contract(INested741TVLABI.abi, inNested741TVL);

        const tx = await Nested741TVLContract.methods
            .TVLrefresh(user, 0, true)
            .send({
                from: accounts[0]
            });

        if (tx.status) {
            alert("TVLrefresh succeeded");
        } else {
            alert("TVLrefresh failed");
        }

    } catch (err) {
        console.error(err);
        alert("TVLrefresh failed: " + (err.message || err));
    }

    hideLoader();
}


async function onCapBurn() {
    showLoader();

    try {
        // Prompt for recipient
        const input = document.getElementById("userAddrInput");
        const user = input.value.trim();

        if (!user || !web3.utils.isAddress(user)) {
            alert("Enter a valid address");
            return;
        }

        const id = await nested.methods.UserToId(user).call();
        const node = await nested.methods.getNode(id).call();
        const stor = node[4];
        if (!stor || stor == ZERO) {
            alert("Instance/Stor not found");
            return;
        }

        const amountStrDollar = prompt("Enter amount to burn:");
        if (!amountStrDollar) {
            throw 'Amount required';
        }
        const amountDollar = parseFloat(amountStrDollar);
        if (isNaN(amountDollar)) {
            throw 'Invalid amount';
        }



        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (user.trim().toLowerCase() !== accounts[0].toLowerCase()) {
            throw "Incorrect account selected";
        }
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const storeContract = new web3T.eth.Contract(IInstanceStorABI.abi, stor);

        const amountOzone = await rule.methods.computeDollarToOzone(web3.utils.toWei(amountDollar.toString(), 'ether')).call();

        const amountOzoneDollar = await rule.methods.computeOzoneToDollar('15447113780431719335934').call();


        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        // prepare method
        const method = storeContract.methods.BurnCoin(
            web3.utils.toWei(amountDollar.toString(), 'ether'),
            maxintervals
        );

        // estimate gas
        const gas = await method.estimateGas({
            from: currentAccount,
            value: amountOzone
        });

        // send tx
        const receipt = await method.send({
            from: currentAccount,
            value: amountOzone,

            gas: Math.floor(gas * 1.1),

            maxPriorityFeePerGas: "1",
            maxFeePerGas: (baseFee + 2n).toString()
        });

        if (receipt.status) {
            alert("Burn succeeded");
        } else {
            alert("Burn failed");
        }

        console.log("Tx Hash:", receipt.transactionHash);
        console.log("Gas Used:", receipt.gasUsed);


    } catch (err) {
        console.error(err);
        alert("Burn failed: " + (err.message || err));
    }

    hideLoader();
}

async function onClaim() {
    showLoader();

    try {
        validateLogin();
        // Prompt for recipient
        const input = document.getElementById("userAddrInput");
        const user = input.value.trim();

        if (!user || !web3.utils.isAddress(user)) {
            alert("Enter a valid address");
            return;
        }

        const id = await nested.methods.UserToId(user).call();
        // Enable wallet
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        if (user.trim().toLowerCase() !== accounts[0].toLowerCase()) {
            throw "Incorrect account selected";
        }
        if (currentAccount != accounts[0]) { throw "Incorrect account selected"; }

        const instancecontract = new web3T.eth.Contract(IInstanceMeABI.abi,
            currentInstance
        );

        const valid =
            await instancecontract.methods.validateToken().call({
                from: accounts[0]
            });

        if (!valid) {
            throw "Login required";
        }

        // get latest base fee
        const block = await web3T.eth.getBlock("latest");
        const baseFee = BigInt(block.baseFeePerGas || 0);

        // estimate gas
        /**/
        const gas = await instancecontract.methods
            .Txn(ZERO, maxintervals, 0, 107)
            .estimateGas({
                from: accounts[0],
                value: "0"
            });

        // send tx
        const receipt = await instancecontract.methods
            .Txn(ZERO, maxintervals, 0, 107)
            .send({
                from: accounts[0],
                value: "0",

                gas: Math.floor(gas * 1.1), // buffer

                maxPriorityFeePerGas: "1", // low tip
                maxFeePerGas: (baseFee + 2n).toString()
            });

        console.log("Txn receipt:", receipt);
        console.log("Tx Hash:", receipt.transactionHash);
        console.log("Gas Used:", receipt.gasUsed);

        if (receipt.status) {
            alert("Claimed succeeded");
        } else {
            alert("Claimed failed");
        }

    } catch (err) {
        console.error(err);
        alert("Claimed failed: " + (err.message || err));
    }

    hideLoader();

}

async function onNFTTransfer(user, orc1155, tokenId, isforce) {
    showLoader();

    try {
        // Prompt for recipient
        const to = prompt("Enter receiver address:");
        if (!to) {
            throw 'Receiver address required';
        }

        // Prompt for amount
        const amountStr = prompt("Enter amount to transfer:");
        if (!amountStr) {
            throw 'Amount required';
        }
        const amount = parseInt(amountStr);
        if (isNaN(amount) || amount <= 0) {
            throw 'Invalid amount';
        }

        // Enable wallet
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });


        window.web3T = new Web3(window.ethereum);
        // Initialize contract
        const orc1155contract = new web3T.eth.Contract(IORC1155ABI.abi, orc1155);
        // Check balance
        const balance = await orc1155contract.methods.balanceOf(user, tokenId).call();
        if (amount > parseInt(balance)) {
            throw 'Insufficient NFT balance';
        }

        if (user.trim().toLowerCase() !== accounts[0].toLowerCase()) {
            const tx1 = await orc1155contract.methods
                .setApprovalForAll(accounts[0], true)
                .send({ from: user });
            if (!tx1.status) throw "Incorrect account selected";
        }

        // Send transfer
        const tx1 = await orc1155contract.methods
            .onTokenTransfer(user, to, tokenId, amount, isforce, "0x")
            .send({ from: accounts[0] });

        console.log(tx1);

        if (tx1.status) {
            alert("Transfer succeeded");
        } else {
            alert("Transfer failed");
        }


    } catch (err) {
        console.error(err);
        alert("Transfer failed: " + (err.message || err));
    }

    hideLoader();

}

async function loadNFTArchive() {

    clearPanels();
    const panel = addPanel("NFT Archive Events");

    try {

        const latestBlock = await web3.eth.getBlockNumber();


        let allEvents = [];

        const transferSingleTopic = web3.utils.sha3(
            "TransferSingle(address,address,address,uint256,uint256)"
        );

        for (let end = latestBlock; end >= minBlock; end -= step) {

            let start = end - step;
            if (start < minBlock) start = minBlock;

            for (let block = start; block <= end; block++) {

                const blockData = await web3.eth.getBlock(block, true);
                if (!blockData || !blockData.transactions) continue;

                for (const tx of blockData.transactions) {

                    const receipt = await web3.eth.getTransactionReceipt(tx.hash);
                    if (!receipt || !receipt.logs) continue;

                    for (const log of receipt.logs) {

                        if (log.topics[0] === transferSingleTopic) {

                            const operator = "0x" + log.topics[1].slice(26);
                            const from = "0x" + log.topics[2].slice(26);
                            const to = "0x" + log.topics[3].slice(26);

                            const decoded = web3.eth.abi.decodeParameters(
                                ["uint256", "uint256"],
                                log.data
                            );

                            const id = decoded[0];
                            const value = decoded[1];

                            allEvents.push({
                                contract: log.address,
                                operator,
                                from,
                                to,
                                id,
                                value,
                                blockNumber: receipt.blockNumber,
                                txHash: receipt.transactionHash
                            });

                        }

                    }

                }

            }

        }

        if (allEvents.length === 0)
            throw new Error("No events found");

        /* sort latest first */

        allEvents.sort((a, b) => b.blockNumber - a.blockNumber);

        for (const ev of allEvents) {

            const e = ev.returnValues;

            const row = document.createElement("div");
            row.className = "row";
            row.style.display = "flex";
            row.style.justifyContent = "space-between";
            row.style.alignItems = "center";

            const left = document.createElement("div");
            left.style.display = "flex";
            left.style.alignItems = "center";
            left.style.gap = "6px";

            const right = document.createElement("div");
            right.style.display = "flex";
            right.style.alignItems = "center";
            right.style.gap = "6px";

            const arrow = document.createElement("span");
            arrow.innerText = "➜";

            /* FROM → TO */

            left.appendChild(renderAddressLongX(ev.from));
            left.appendChild(arrow);
            left.appendChild(renderAddressLongX(ev.to));

            /* RIGHT SIDE INFO */

            const info = document.createElement("span");

            info.innerText =
                "Block: " + ev.blockNumber +
                " | TokenId: " + ev.id +
                " | Amount: " + ev.value +
                " | Sender:";

            right.appendChild(info);

            /*if(e.sender){
                right.appendChild(renderAddress(e.sender));
            }*/

            row.appendChild(left);
            row.appendChild(right);

            panel.appendChild(row);
        }

    }
    catch (err) {
        console.error(err);
        addRow(panel, "Error", err.message);
        addRow(panel, "Error", "Failed to load events");
    }

    hideLoader();
}

async function loadValidatorPage() {

    clearPanels();
    const panel = addPanel("Validator Module");
    try {
        const row = document.createElement("div");
        row.className = "row";

        const left = document.createElement("div");

        const btnGetUserDeligator = document.createElement("button");
        btnGetUserDeligator.innerText = "Get User's Deligator";
        btnGetUserDeligator.style.marginLeft = "10px";

        btnGetUserDeligator.onclick = async () => {
            try {
                const input = document.getElementById("userAddrInput");
                const user = input.value.trim();
                if (!user || !web3.utils.isAddress(user)) {
                    alert("Enter a valid Ethereum address");
                    return;
                }

                // Enable wallet
                //const accounts = await ethereum.request({ method: 'eth_requestAccounts' });

                //if(currentAccount.trim().toLowerCase() !== accounts[0].toLowerCase())
                //    throw "Incorrect account selected";

                // Initialize contract
                //const validatorcontract = new web3.eth.Contract(validatorsLocalsABI, validatorsLocalsAddress);


                const valdelact = await validator.methods.getValidatorDelegatorOfUser(user).call();
                const inc = await validator.methods.incomeOf(user).call();

                const subrow = document.createElement("div");
                subrow.className = "row";

                const right1 = document.createElement("div");
                right1.innerHTML = "User: " + user + " | Income: " + inc;

                const right2 = document.createElement("div");
                right2.innerHTML =
                    "Validator: " + valdelact[0] + " | Delegator: " + valdelact[1] + " | Active: " + valdelact[2];

                subrow.appendChild(right1);

                const subrow2 = document.createElement("div");
                subrow2.className = "row";
                subrow2.appendChild(right2);

                panel.appendChild(subrow);
                panel.appendChild(subrow2);
            }
            catch (err) {
                console.error(err);
                addRow(panel, "Error", err.message);
                addRow(panel, "Error", "Failed to Deligator Module");
            }
        };

        left.appendChild(btnGetUserDeligator);

        row.appendChild(left);
        panel.appendChild(row);

    }
    catch (err) {
        console.error(err);
        alert("Validator failed: " + (err.message || err));
        addRow(panel, "Error", err.message);
        addRow(panel, "Error", "Failed to Validator Module");
    }

    hideLoader();
}

async function renderULTreePanel() {
    clearPanels();
    const panel = addPanel("🌳 Upline + Downline View");

    // ---------- INPUT UI ----------
    const inputWrap = document.createElement("div");
    inputWrap.style.display = "flex";
    inputWrap.style.alignItems = "center";
    inputWrap.style.gap = "10px";
    inputWrap.style.marginBottom = "12px";

    const input = document.createElement("input");
    input.placeholder = "Enter wallet address...";
    input.style.flex = "1";
    input.style.padding = "8px 10px";
    input.style.borderRadius = "8px";
    input.style.border = "1px solid #2a3a5a";
    input.style.background = "#0b0f1a";
    input.style.color = "#00ffff";

    const btn = document.createElement("button");
    btn.textContent = "Load Tree";
    btn.style.padding = "8px 14px";
    btn.style.borderRadius = "8px";
    btn.style.background = "linear-gradient(135deg,#00ffff,#3fa9ff)";
    btn.style.border = "none";

    const btnIncView = document.createElement("button");
    btnIncView.textContent = "Income View";
    btnIncView.style.padding = "8px 14px";
    btnIncView.style.borderRadius = "8px";
    btnIncView.style.background = "linear-gradient(135deg,#00ffff,#3fa9ff)";
    btnIncView.style.border = "none";

    inputWrap.appendChild(input);
    inputWrap.appendChild(btn);
    inputWrap.appendChild(btnIncView);
    panel.appendChild(inputWrap);

    // ---------- CONTAINER ----------
    const container = document.createElement("div");
    container.className = "ulTreeWrap";
    panel.appendChild(container);

    // ---------- STYLE ----------
    const style = document.createElement("style");
    style.innerHTML = `
        .ulTreeWrap ul { 
            list-style:none; 
            padding-left:15px; 
        }

        .ulTreeWrap li { 
            margin:3px 0; 
            color:#00ffff; 
            font-size:12px;
        }

        /* 👇 clickable area ONLY */
        .ulTreeWrap .node {
            display: inline-block;
            cursor: pointer;
            padding: 2px 6px;
            transition: all 0.2s ease;
        }

        .ulTreeWrap .node:hover {
            background: rgba(0,255,255,0.15);
            border-radius: 4px;
        }
  `;
    document.head.appendChild(style);

    // ---------- HELPERS ----------
    function shortAddr(addr) {
        if (!addr) return "----";

        return `
        <span 
            class="shortAddr clickableAddr"
            data-full="${addr}"
            style="cursor:pointer;"
        >
            ${addr.slice(0, 6)}...${addr.slice(-4)}
        </span>
    `;
    }

    async function getNode(id) {
        const n = await nested.methods.getNode(id).call();
        const storC = new web3.eth.Contract(IInstanceStorABI.abi, n[4]);

        let rnk = await storC.methods.rank().call();

        return { id: n[0].toString(), pid: n[2], address: n[1], rank: rnk };
    }

    async function getChildren(id) {

        const getNodeDirectsCount = await nested.methods.getNodeDirectsCount(id).call()
        const arr = [];

        for (let i = 0; i < getNodeDirectsCount && i < 10; i++) {
            arr.push(await getNode(await nested.methods.getNodeChild(id, i).call()));
        }
        return arr;
    }

    // ---------- BUILD DOWNLINE ----------
    async function buildDownline(parentId, level = 1) {
        if (level > MAX_LEVEL) return null;

        const children = await getChildren(parentId);
        if (!children.length) return null;

        const ul = document.createElement("ul");

        for (let c of children) {
            const li = document.createElement("li");

            li.addr = c.address;
            li.innerHTML = `<span class="node">${c.id} (${c.rank}*...${shortAddr(c.address)})</span>`;

            // 🔁 recursive call
            const childUL = await buildDownline(c.id, level + 1);
            if (childUL) li.appendChild(childUL);

            ul.appendChild(li);
        }

        return ul;
    }
    // ---------- LOAD ----------
    const MAX_LEVEL = 7; // 👈 change this anytime (2,3,4...)
    async function loadTree(addr) {

        container.innerHTML = "⏳ Loading...";

        try {
            const selfid = await nested.methods.UserToId(addr).call();
            const info = await nested.methods.getNode(selfid).call();
            const storC = new web3.eth.Contract(IInstanceStorABI.abi, info[4]);;

            let rnk = await storC.methods.rank().call();

            let pid = info[2];

            const chain = [];

            // 🔥 SELF NODE
            const selfNode = { id: selfid, pid: pid, address: addr, rank: rnk };
            chain.push(selfNode);

            // 🔼 UPLINE
            while (pid != 0) {

                const node = await getNode(pid);
                chain.push(node);
                pid = node.pid;
            }

            chain.reverse();

            // ---------- BUILD TREE ----------
            const ul = document.createElement("ul");
            ul.id = "mainTree";

            // ✅ ADD CLICK HERE 👇
            ul.addEventListener("click", (e) => {
                const li = e.target.closest("li");
                if (!li || !li.addr) return;

                console.log("👤 Clicked (main UL):", li.addr);

                // reload tree OR call your panel
                loadTree(li.addr);   // OR renderULTreePanel(li.addr)
            });




            let currentUL = ul;
            let lastLI = null;

            for (let i = 0; i < chain.length; i++) {

                const n = chain[i];

                const li = document.createElement("li");
                if (n.id == selfid)
                    li.innerHTML = `<span class="node">${n.id} (${n.rank}*...${shortAddr(n.address)})🧑‍💻</span>`;
                else
                    li.innerHTML = `<span class="node">${n.id} (${n.rank}*...${shortAddr(n.address)})</span>`;
                const nextUL = document.createElement("ul");

                li.addr = n.address;
                li.appendChild(nextUL);
                currentUL.appendChild(li);

                currentUL = nextUL;
                lastLI = li;
            }

            // 🔽 ADD DOWNLINE (ONLY FOR SELF NODE)
            if (selfid) {
                const downUL = await buildDownline(selfid, 1);
                if (downUL) lastLI.appendChild(downUL);
            }
            container.innerHTML = "";
            container.appendChild(ul);

        } catch (e) {
            console.error(e);
            container.innerHTML = "❌ Error";
        }
    }

    // ---------- CLICK ----------
    btn.onclick = () => {
        const addr = input.value.trim();
        if (!addr) return alert("Enter address");
        loadTree(addr);
    };


    // ---------- LOAD INCOME VIEW ----------
    async function loadIncomeView(addr) {
        runTableTrace(await buildDataSet(addr), rankClauses)
    }

    async function buildDataSet(addr) {

        const ranks = [];
        const ages = [];

        // 🔹 get node info from address
        let uid = await nested.methods.UserToId(addr).call();

        for (let lvl = 0; lvl < 16 && uid != 0; lvl++) {


            // 🔹 get node details
            const node = await nested.methods.getNode(uid).call();
            const storAddr = node[4];

            let rank = 0;
            let age = 0;

            if (storAddr !== "0x0000000000000000000000000000000000000000") {

                const stor = new web3.eth.Contract(IInstanceStorABI.abi, storAddr);
                const res = await stor.methods.getRankWithAgeValue().call();

                rank = Number(res[0]);
                age = Number(res[1]);
            }

            ranks.push(rank);
            ages.push(age);

            uid = node[2];
        }

        // 🔁 reverse to match Solidity (top → down)
        //ranks.reverse();
        //ages.reverse();

        return { ranks, ages };
    }

    async function runTableTrace(dataSet, rankClause) {

        const panel = addPanel("📊 Income Trace");

        const currentAgeNow = Number(sysAge);

        addRow(panel, "Current Age", currentAgeNow);

        let iRnk = 0;
        let ieRnk = 0;
        let igRnk = 0;
        let igPrd = 0;
        let iOutDay = false;

        let lastrnk = null;

        const length = dataSet.ranks.length;
        const table = document.createElement("table");
        table.style.fontFamily = "monospace";

        const header = `
    <tr>
    <th>Lvl</th><th></th><th>Rank</th><th>Last</th><th>Age</th>
    <th>iRnk</th><th>ieRnk</th><th>igRnk</th><th>igPrd</th><th>Out</th>
    </tr>`;
        table.innerHTML = header;
        table.style.textAlign = "right";

        panel.appendChild(table);

        for (let lvl = 0; lvl < length; lvl++) {

            const currentrnk = dataSet.ranks[lvl] ?? 0;
            const currentAge = dataSet.ages[lvl] ?? 0;

            let isSkipped = false;

            let iRnkStr = "";
            let ieRnkStr = "";
            let igRnkStr = "";
            let igPrdStr = "";
            let iOutDayStr = "";

            // ---------- LEVEL 0 ----------
            if (lvl === 0) {

                const r0 = rankClause[currentrnk] || {};

                ieRnk = r0.eRnk || 0;
                igRnk = r0.gRnk || 0;
                igPrd = r0.gPrd || 0;

                iRnk = currentrnk;
                lastrnk = currentrnk;

                iOutDay = (currentAgeNow - currentAge) > igPrd;

                iRnkStr = iRnk;
                ieRnkStr = ieRnk;
                igRnkStr = igRnk;
                igPrdStr = igPrd;
                iOutDayStr = iOutDay;
            }

            // ---------- MAIN LOGIC ----------
            if (lvl > 0 && currentrnk !== lastrnk) {

                if (currentrnk !== iRnk) {

                    const r = rankClause[currentrnk] || {};

                    if (currentrnk > iRnk) {

                        iRnk = currentrnk;
                        ieRnk = r.eRnk || 0;
                        igRnk = r.gRnk || 0;
                        igPrd = r.gPrd || 0;

                        iOutDay = (currentAgeNow - currentAge) > igPrd;

                        iRnkStr = iRnk;
                        ieRnkStr = ieRnk;
                        igRnkStr = igRnk;
                        igPrdStr = igPrd;
                        iOutDayStr = iOutDay;
                    }
                }

                isSkipped = !(
                    (currentrnk >= ieRnk) ||
                    (currentrnk >= igRnk && currentrnk < ieRnk && !iOutDay)
                );

            }

            // ---------- RENDER ROW ----------
            const row = document.createElement("tr");
            row.innerHTML = `
        <td>${lvl}</td>
        <td>${isSkipped ? "❌" : "✅"}</td>
        <td>${currentrnk}</td>
        <td>${lastrnk}</td>
        <td>${currentAge}</td>
        <td>${iRnkStr}</td>
        <td>${ieRnkStr}</td>
        <td>${igRnkStr}</td>
        <td>${igPrdStr}</td>
        <td>${iOutDayStr}</td>
        `;
            if (isSkipped) row.style.color = "#ff4d4d";       // red
            else if (iRnkStr) row.style.color = "#00ff9f";    // green
            else row.style.color = "#00ffff";                 // cyan
            table.appendChild(row);
            lastrnk = currentrnk;
        }
    }


    btnIncView.onclick = () => {
        const addr = input.value.trim();
        if (!addr) return alert("Enter address");
        loadIncomeView(addr);
    };



    input.addEventListener("keypress", (e) => {
        if (e.key === "Enter") btn.click();
    });
}



async function renderTxLogPanel() {

    const panel = addPanel("📜 Transaction Event Logs");

    // ---------- INPUT UI ----------
    const inputWrap = document.createElement("div");
    inputWrap.style.display = "flex";
    inputWrap.style.alignItems = "center";
    inputWrap.style.gap = "10px";
    inputWrap.style.marginBottom = "12px";

    const input = document.createElement("input");
    input.placeholder = "Enter transaction hash (0x...)";
    input.style.flex = "1";
    input.style.padding = "8px 10px";
    input.style.borderRadius = "8px";
    input.style.border = "1px solid #2a3a5a";
    input.style.background = "#0b0f1a";
    input.style.color = "#00ffff";

    const btn = document.createElement("button");
    btn.textContent = "Load Logs";
    btn.style.padding = "8px 14px";
    btn.style.borderRadius = "8px";
    btn.style.background = "linear-gradient(135deg,#00ffff,#3fa9ff)";
    btn.style.border = "none";

    inputWrap.appendChild(input);
    inputWrap.appendChild(btn);
    panel.appendChild(inputWrap);

    // ---------- CONTAINER ----------
    const summaryDiv = document.createElement("div");
    summaryDiv.className = "txLogSummary";
    panel.appendChild(summaryDiv);

    const container = document.createElement("div");
    container.className = "txLogWrap";
    panel.appendChild(container);

    // ---------- STYLE ----------
    const style = document.createElement("style");
    style.innerHTML = `
        .txLogWrap table {
            width: 100%;
            font-family: monospace;
            font-size: 12px;
            border-collapse: collapse;
            margin-top: 8px;
        }
        .txLogWrap th, .txLogWrap td {
            border: 1px solid #2a3a5a;
            padding: 5px;
            color: #00ffff;
            word-break: break-all;
        }
        .txLogWrap h4 {
            color: #3fa9ff;
            margin: 16px 0 8px;
        }
        .txLogSummary .row {
            color: #ccc;
        }
        .txTraceError td {
            color: #ff6b6b !important;
        }
        .txTraceDepth td:nth-child(2) {
            color: #8ec8ff;
        }
        .txInternalValue td {
            color: #7bed9f !important;
        }
        .txInternalExternal td {
            color: #feca57 !important;
        }
        .txLogWrap td.nobreakword,
        .txLogWrap th.nobreakword {
            word-break: normal;
            white-space: nowrap;
        }
        .txLogWrap td.inputwidth,
        .txLogWrap th.inputwidth {
            word-break: normal;
           width: 200px;
        }
    `;
    document.head.appendChild(style);

    // ---------- HELPERS ----------
    function shortAddr(addr) {
        if (!addr) return "----";

        if (addr === "-" || addr === "(contract creation)" || addr === "(create)" || !String(addr).startsWith("0x")) {
            return String(addr);
        }

        return '<span class="shortAddr clickableAddr" data-full="' + addr + '" style="cursor:pointer;" title="Click to copy">' +
            addr.slice(0, 6) + "..." + addr.slice(-4) + "</span>";
    }

    function setCellContent(td, cell) {
        if (typeof cell === "string" && cell.indexOf("<") >= 0) {
            td.innerHTML = cell;
        } else {
            td.innerText = cell;
        }
    }

    function addSummaryRow(parent, label, value) {
        const row = document.createElement("div");
        row.className = "row";
        if (typeof value === "string" && value.indexOf("<") >= 0) {
            row.innerHTML = "<b>" + label + ":</b> " + value;
        } else {
            row.innerHTML = "<b>" + label + ":</b> " + (value != null ? value : "-");
        }
        parent.appendChild(row);
    }

    function bindCopyClick(root) {
        root.addEventListener("click", function (e) {
            const el = e.target.closest(".clickableAddr, .clickableHex");
            if (!el) return;

            const full = el.getAttribute("data-full");
            if (!full) return;

            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(full).then(function () {
                    const prev = el.textContent;
                    el.textContent = "Copied!";
                    setTimeout(function () {
                        el.textContent = prev;
                    }, 900);
                }).catch(function () { });
            }
        });
    }

    const EVENT_TOPICS = {
        LogTxns: "0x1517c86fcf2bfb8e3468afcc539b0004955da8027797c497ea51d1f1094ab898",
        CapReset: "0xb359d8408cffc6b8788774a87b59f0d5be825576ea5fdd7b0917fed6a07e8030",
        TVLClaimTxnLog: "0x651be9e06b82f2bfd92524ddb5eab4f5bce9aec2963c2417fa0337eb9cdd65ee",
        EthTransferred: "0xcec1f18c3ab8ddaaa107a1591e3c369667eec613626611a8deaedef43069fcdd",
        TransferSingle: "0xc3d58168c5ae7397731d063d5bbf3d657854427343f4c083240f7aacaa2d0f62",
        TransferBatch: "0x4a39dc06d4c0dbc64b70af90fd698a233a518aa5d07e595d983b8c0526c8f7fb",
        ApprovalForAll: "0x17307eab39ab6107e8899845ad3d59bd9653f200f220920489ca2b5937696c31",
    };

    const EVENT_ABIS = {
        LogTxns: [
            { name: "from", type: "address", indexed: false },
            { name: "orc1155", type: "address", indexed: false },
            { name: "_amt", type: "uint256", indexed: false },
            { name: "_value", type: "uint256", indexed: false },
            { name: "_time", type: "uint256", indexed: false },
            { name: "_type", type: "uint256", indexed: false },
        ],
        CapReset: [
            { name: "invested", type: "uint256", indexed: false },
            { name: "claimed", type: "uint256", indexed: false },
            { name: "claimedDollar", type: "uint256", indexed: false },
            { name: "investedDollar", type: "uint256", indexed: false },
            { name: "burned", type: "uint256", indexed: false },
            { name: "burnedDollar", type: "uint256", indexed: false },
            { name: "ag", type: "uint256", indexed: false },
        ],
        TVLClaimTxnLog: [
            { name: "to", type: "address", indexed: false },
            { name: "value", type: "uint256", indexed: false },
            { name: "flush", type: "uint256", indexed: false },
            { name: "_time", type: "uint256", indexed: false },
        ],
        EthTransferred: [
            { name: "to", type: "address", indexed: true },
            { name: "amount", type: "uint256", indexed: false },
        ],
        TransferSingle: [
            { name: "operator", type: "address", indexed: true },
            { name: "from", type: "address", indexed: true },
            { name: "to", type: "address", indexed: true },
            { name: "id", type: "uint256", indexed: false },
            { name: "value", type: "uint256", indexed: false },
        ],
        TransferBatch: [
            { name: "operator", type: "address", indexed: true },
            { name: "from", type: "address", indexed: true },
            { name: "to", type: "address", indexed: true },
            { name: "ids", type: "uint256[]", indexed: false },
            { name: "values", type: "uint256[]", indexed: false },
        ],
        ApprovalForAll: [
            { name: "account", type: "address", indexed: true },
            { name: "operator", type: "address", indexed: true },
            { name: "approved", type: "bool", indexed: false },
        ],
    };

    const LOG_TYPE_LABELS = {
        0: "Import",
        1: "Level 1", 2: "Level 2", 3: "Level 3", 4: "Level 4", 5: "Level 5",
        6: "Level 6", 7: "Level 7", 8: "Level 8", 9: "Level 9",
        71: "Reward p1/f1", 72: "Royalty p2/f2", 73: "Self p3/f3",
        74: "Yield p4/f4", 75: "Validator p5/f5", 76: "Tour1 p6/f6", 77: "Tour2 p7/f7",
        78: "Cap total", 79: "Claim total",
        100: "MintBySystem", 101: "Mint",
        107: "Claim treasury (net)", 108: "Claim (self)", 109: "Claim (self flush)",
        110: "BurnCoin(target1)", 111: "BurnCoin(target2)"
    };

    function formatUintArray(arr) {
        if (!arr || !arr.length) return "-";
        return arr.map(String).join(", ");
    }

    function logTypeLabel(typeNum) {
        if (LOG_TYPE_LABELS[typeNum]) {
            return String(typeNum) + " (" + LOG_TYPE_LABELS[typeNum] + ")";
        }
        if (typeNum >= 70 && typeNum <= 77) {
            return String(typeNum) + " (Income " + (typeNum - 70) + ")";
        }
        return String(typeNum);
    }

    function logAgeLabel(age) {
        const n = Number(age);
        if (!n) return String(age);
        const range = getAgeDateRange(n);
        return range.start + " {" + n + "}";
    }

    function normalizeHash(txHash) {
        if (!txHash) return "";
        let hash = String(txHash).trim();
        if (!hash.startsWith("0x")) hash = "0x" + hash;
        return hash;
    }

    function decodeLog(log) {
        const topic0 = (log.topics && log.topics[0] || "").toLowerCase();

        for (const eventName in EVENT_TOPICS) {
            if (topic0 !== EVENT_TOPICS[eventName].toLowerCase()) continue;

            const decoded = web3.eth.abi.decodeLog(
                EVENT_ABIS[eventName],
                log.data,
                log.topics.slice(1)
            );

            return {
                eventName: eventName,
                logIndex: log.logIndex,
                address: log.address,
                decoded: decoded,
            };
        }
        return null;
    }

    function summarizeLog(parsed) {
        const d = parsed.decoded;

        if (parsed.eventName === "LogTxns") {
            return [
                "from=" + shortAddr(d.from),
                "orc1155=" + shortAddr(d.orc1155),
                "amt=" + formatOZN(d._amt),
                "value=" + formatOZN(d._value),
                "time=" + logAgeLabel(d._time),
                "type=" + logTypeLabel(Number(d._type)),
            ].join(" | ");
        }

        if (parsed.eventName === "CapReset") {
            return [
                "invested=" + formatOZN(d.invested),
                "claimed=" + formatOZN(d.claimed),
                "claimed$=" + formatOZN(d.claimedDollar),
                "invested$=" + formatOZN(d.investedDollar),
                "burned=" + formatOZN(d.burned),
                "burned$=" + formatOZN(d.burnedDollar),
                "age=" + logAgeLabel(d.ag),
            ].join(" | ");
        }

        if (parsed.eventName === "TVLClaimTxnLog") {
            return [
                "to=" + shortAddr(d.to),
                "value=" + formatOZN(d.value),
                "flush=" + formatOZN(d.flush),
                "time=" + logAgeLabel(d._time),
            ].join(" | ");
        }

        if (parsed.eventName === "EthTransferred") {
            return [
                "to=" + shortAddr(d.to),
                "amount=" + formatOZN(d.amount),
            ].join(" | ");
        }

        if (parsed.eventName === "TransferSingle") {
            return [
                "operator=" + shortAddr(d.operator),
                "from=" + shortAddr(d.from),
                "to=" + shortAddr(d.to),
                "id=" + String(d.id),
                "value=" + String(d.value),
            ].join(" | ");
        }

        if (parsed.eventName === "TransferBatch") {
            return [
                "operator=" + shortAddr(d.operator),
                "from=" + shortAddr(d.from),
                "to=" + shortAddr(d.to),
                "ids=[" + formatUintArray(d.ids) + "]",
                "values=[" + formatUintArray(d.values) + "]",
            ].join(" | ");
        }

        if (parsed.eventName === "ApprovalForAll") {
            return [
                "account=" + shortAddr(d.account),
                "operator=" + shortAddr(d.operator),
                "approved=" + String(d.approved),
            ].join(" | ");
        }

        return JSON.stringify(d);
    }

    function summarizeRawLog(log) {
        const topics = (log.topics || []).map(function (t, i) {
            return "t" + i + "=" + t;
        }).join(" ");
        const data = log.data || "0x";
        const shortData = data.length > 66 ? data.slice(0, 66) + "..." : data;
        return (topics ? topics + " " : "") + "data=" + shortData;
    }

    function decodeInputCall(tx) {
        if (!tx || !tx.input || tx.input === "0x" || tx.input.length < 10) {
            return "-";
        }
        return decodeCalldataInput(tx.input);
    }

    function createTable(headers, rows) {
        const table = document.createElement("table");
        const thead = document.createElement("thead");
        const headRow = document.createElement("tr");

        headers.forEach(function (h) {
            const th = document.createElement("th");
            th.innerText = h;
            headRow.appendChild(th);
        });
        thead.appendChild(headRow);
        table.appendChild(thead);

        const tbody = document.createElement("tbody");
        if (!rows.length) {
            const tr = document.createElement("tr");
            const td = document.createElement("td");
            td.colSpan = headers.length;
            td.innerText = "No events found";
            td.style.textAlign = "center";
            tr.appendChild(td);
            tbody.appendChild(tr);
        } else {
            rows.forEach(function (cells) {
                const tr = document.createElement("tr");
                cells.forEach(function (cell) {
                    const td = document.createElement("td");
                    setCellContent(td, cell);
                    tr.appendChild(td);
                });
                tbody.appendChild(tr);
            });
        }

        table.appendChild(tbody);
        return table;
    }

    function appendTable(parent, title, table) {
        const heading = document.createElement("h4");
        heading.innerText = title;
        parent.appendChild(heading);
        parent.appendChild(table);
    }

    function getRpcUrl() {
        const provider = web3 && web3.currentProvider;
        if (provider) {
            if (provider.host) return provider.host;
            if (provider.connection && provider.connection.url) return provider.connection.url;
        }
        if (typeof RPC_URL !== "undefined" && RPC_URL) return RPC_URL;
        return null;
    }

    function hexToDec(hex) {
        if (!hex || hex === "0x") return "-";
        try {
            return String(parseInt(hex, 16));
        } catch (err) {
            return String(hex);
        }
    }

    function copyableHex(hex, label) {
        if (!hex || hex === "0x") return "-";
        const text = String(hex);
        if (text.length <= 20) return text;

        const preview = text.slice(0, 10) + "..." + text.slice(-6);
        const byteLen = Math.floor((text.length - 2) / 2);
        const kind = label || "data";

        return (
            '<span class="clickableHex clickableAddr" data-full="' + text + '" ' +
            'style="cursor:pointer;" title="Click to copy ' + kind + ' (' + byteLen + ' bytes)">' +
            preview + " [" + byteLen + "b]" +
            "</span>"
        );
    }

    function getSignatureMap() {
        if (typeof SIGNATURES !== "undefined" && SIGNATURES && SIGNATURES.functions) {
            return SIGNATURES.functions;
        }
        return {};
    }

    function getErrorSignatureMap() {
        if (typeof SIGNATURES !== "undefined" && SIGNATURES && SIGNATURES.errors) {
            return SIGNATURES.errors;
        }
        return {};
    }

    function splitSignatureTypes(paramsStr) {
        const types = [];
        let depth = 0;
        let cur = "";

        for (let i = 0; i < paramsStr.length; i++) {
            const c = paramsStr[i];
            if (c === "(") depth++;
            else if (c === ")") depth--;
            else if (c === "," && depth === 0) {
                if (cur.trim()) types.push(cur.trim());
                cur = "";
                continue;
            }
            cur += c;
        }

        if (cur.trim()) types.push(cur.trim());
        return types;
    }

    function parseFunctionSignature(signature) {
        const nameEnd = signature.indexOf("(");
        if (nameEnd < 0) return { name: signature, types: [] };

        const paramsStr = signature.slice(nameEnd + 1, -1).trim();
        return {
            name: signature.slice(0, nameEnd),
            types: paramsStr ? splitSignatureTypes(paramsStr) : [],
        };
    }

    function isAbiDecodableType(type) {
        const base = String(type).replace(/\[\d*\]$/, "");
        if (["address", "bool", "string", "bytes", "bytes32", "bytes4"].indexOf(base) >= 0) return true;
        if (/^u?int\d*$/.test(base)) return true;
        if (/^bytes\d+$/.test(base)) return true;
        return false;
    }

    function canDecodeSignatureTypes(types) {
        if (!types || !types.length) return true;
        for (let i = 0; i < types.length; i++) {
            if (!isAbiDecodableType(types[i])) return false;
        }
        return true;
    }

    function formatDecodedArg(type, value) {
        if (type === "address") return shortAddr(value);
        if (type === "bool") return String(value);
        if (type.endsWith("[]")) {
            const inner = type.slice(0, -2);
            return "[" + (value || []).map(function (v) {
                return formatDecodedArg(inner, v);
            }).join(", ") + "]";
        }
        if (type === "string" && String(value).length > 48) {
            return '"' + String(value).slice(0, 24) + '..."';
        }
        return String(value);
    }

    function decodeCalldataInput(input) {
        if (!input || input === "0x") return "(fallback/receive)";
        if (input.length < 10) return copyableHex(input, "input");

        const selector = input.slice(0, 10).toLowerCase();
        const signature = getSignatureMap()[selector];
        if (!signature) return selector + " " + copyableHex(input, "input");

        const parsed = parseFunctionSignature(signature);
        if (!parsed.types.length) return parsed.name + "()";

        if (!canDecodeSignatureTypes(parsed.types)) {
            return parsed.name + "(" + parsed.types.join(", ") + ")";
        }

        try {
            const decoded = web3.eth.abi.decodeParameters(parsed.types, "0x" + input.slice(10));
            const parts = parsed.types.map(function (type, i) {
                return formatDecodedArg(type, decoded[i]);
            });
            return parsed.name + "(" + parts.join(", ") + ")";
        } catch (err) {
            return parsed.name + "(" + parsed.types.join(", ") + ") " + copyableHex(input, "input");
        }
    }

    function decodeRevertOutput(output) {
        if (!output || output === "0x" || output.length < 10) return null;

        const selector = output.slice(0, 10).toLowerCase();
        const errSig = getErrorSignatureMap()[selector];
        if (errSig) return errSig;

        if (output.startsWith("0x08c379a0") && output.length > 10) {
            try {
                const reason = web3.eth.abi.decodeParameter("string", "0x" + output.slice(10));
                return 'Error("' + reason + '")';
            } catch (err) { }
        }

        return null;
    }

    function decodeTraceInput(input) {
        return decodeCalldataInput(input);
    }

    function hasNonZeroValue(value) {
        if (!value || value === "0x" || value === "0x0") return false;
        try {
            return BigInt(value) > 0n;
        } catch (err) {
            return false;
        }
    }

    function isInternalTxnType(type) {
        const t = String(type || "").toUpperCase();
        return t === "CALL" || t === "DELEGATECALL" || t === "CREATE" || t === "CREATE2" || t === "SELFDESTRUCT";
    }

    function internalTxnKind(step) {
        const type = String(step.type || "").toUpperCase();
        if (type === "CREATE" || type === "CREATE2") return "Contract Create";
        if (type === "SELFDESTRUCT") return "Selfdestruct";
        if (hasNonZeroValue(step.value)) return "Value Transfer";
        return "Internal Call";
    }

    function flattenInternalTxns(step, depth, seq, rows) {
        if (!step) return;

        const calls = step.calls || [];
        for (let i = 0; i < calls.length; i++) {
            const child = calls[i];
            if (!child || !isInternalTxnType(child.type)) continue;

            const rowIndex = seq.counter++;
            const hasError = !!child.error;
            const hasValue = hasNonZeroValue(child.value);

            rows.push({
                hasError: hasError,
                hasValue: hasValue,
                cells: [
                    String(rowIndex),
                    String(depth + 1),
                    internalTxnKind(child),
                    child.type || "-",
                    shortAddr(child.from || "-"),
                    shortAddr(child.to || child.address || "(create)"),
                    hasValue ? formatOZN(child.value) : "-",
                    hexToDec(child.gasUsed),
                    hasError ? "Failed" : "Success",
                    decodeTraceInput(child.input),
                ],
            });

            flattenInternalTxns(child, depth + 1, seq, rows);
        }
    }

    function buildInternalTxnRows(trace, tx, statusOk) {
        const rows = [];
        const seq = { counter: 1 };

        if (tx) {
            rows.push({
                hasError: !statusOk,
                hasValue: hasNonZeroValue(tx.value),
                isExternal: true,
                cells: [
                    "0",
                    "0",
                    "External Tx",
                    "CALL",
                    shortAddr(tx.from || "-"),
                    shortAddr(tx.to || "(contract creation)"),
                    hasNonZeroValue(tx.value) ? formatOZN(tx.value) : "-",
                    "-",
                    statusOk ? "Success" : "Failed",
                    decodeInputCall(tx),
                ],
            });
        }

        if (trace) {
            flattenInternalTxns(trace, 0, seq, rows);
        }

        return rows;
    }

    function countInternalValueTransfers(rows) {
        let count = 0;
        rows.forEach(function (row) {
            if (row.hasValue && !row.isExternal) count++;
        });
        return count;
    }

    function createInternalTxnTable(headers, rows) {
        const table = document.createElement("table");
        const thead = document.createElement("thead");
        const headRow = document.createElement("tr");
        const statusColIndex = headers.indexOf("Status");
        const inputColIndex = headers.indexOf("Input");

        headers.forEach(function (h, i) {
            const th = document.createElement("th");
            th.innerText = h;
            if (i === statusColIndex) th.className = "nobreakword";
            if (i === inputColIndex) th.className = "inputwidth";

            headRow.appendChild(th);
        });
        thead.appendChild(headRow);
        table.appendChild(thead);

        const tbody = document.createElement("tbody");
        if (!rows.length) {
            const tr = document.createElement("tr");
            const td = document.createElement("td");
            td.colSpan = headers.length;
            td.innerText = "No internal transactions found";
            td.style.textAlign = "center";
            tr.appendChild(td);
            tbody.appendChild(tr);
        } else {
            rows.forEach(function (row) {
                const tr = document.createElement("tr");
                if (row.isExternal) tr.className = "txInternalExternal";
                else if (row.hasError) tr.className = "txTraceError";
                else if (row.hasValue) tr.className = "txInternalValue";

                row.cells.forEach(function (cell, i) {
                    const td = document.createElement("td");
                    if (i === statusColIndex) td.className = "nobreakword";
                    if (i === inputColIndex) td.className = "inputwidth";
                    setCellContent(td, cell);
                    tr.appendChild(td);
                });
                tbody.appendChild(tr);
            });
        }

        table.appendChild(tbody);
        return table;
    }

    function summarizeTraceResult(step) {
        if (step.error) {
            let text = step.error;
            if (step.revertReason) text += " | " + step.revertReason;
            if (step.output) {
                const decodedErr = decodeRevertOutput(step.output);
                if (decodedErr) text += " | " + decodedErr;
            }
            return text;
        }
        if (step.type === "CREATE" && step.to) return "created=" + shortAddr(step.to);
        if (step.output && step.output !== "0x") {
            const decodedErr = decodeRevertOutput(step.output);
            if (decodedErr) return decodedErr;
            return copyableHex(step.output, "output");
        }
        return "-";
    }

    function flattenTraceSteps(step, depth, seq, rows) {
        if (!step) return;

        const rowIndex = seq.counter++;
        const hasError = !!step.error;

        rows.push({
            hasError: hasError,
            depth: depth,
            cells: [
                String(rowIndex),
                String(depth),
                step.type || "-",
                shortAddr(step.from || "-"),
                shortAddr(step.to || step.address || "(create)"),
                step.value && step.value !== "0x0" && step.value !== "0x"
                    ? formatOZN(step.value)
                    : "-",
                hexToDec(step.gasUsed),
                decodeTraceInput(step.input),
                summarizeTraceResult(step),
            ],
        });

        const calls = step.calls || [];
        for (let i = 0; i < calls.length; i++) {
            flattenTraceSteps(calls[i], depth + 1, seq, rows);
        }
    }

    function createTraceTable(headers, rows) {
        const table = document.createElement("table");
        const thead = document.createElement("thead");
        const headRow = document.createElement("tr");
        const inputColIndex = headers.indexOf("Input");
        const outputColIndex = headers.indexOf("Output / Error");
        const nobreakHeaders = ["#", "Depth", "Type", "Value", "Gas Used"];

        function traceCellClass(i) {
            const h = headers[i];
            if (nobreakHeaders.indexOf(h) >= 0) return "nobreakword";
            if (i === inputColIndex || i === outputColIndex) return "inputwidth";
            return "";
        }

        headers.forEach(function (h, i) {
            const th = document.createElement("th");
            th.innerText = h;
            const cls = traceCellClass(i);
            if (cls) th.className = cls;
            headRow.appendChild(th);
        });
        thead.appendChild(headRow);
        table.appendChild(thead);

        const tbody = document.createElement("tbody");
        if (!rows.length) {
            const tr = document.createElement("tr");
            const td = document.createElement("td");
            td.colSpan = headers.length;
            td.innerText = "No trace steps found";
            td.style.textAlign = "center";
            tr.appendChild(td);
            tbody.appendChild(tr);
        } else {
            rows.forEach(function (row) {
                const tr = document.createElement("tr");
                if (row.hasError) tr.className = "txTraceError";
                else if (row.depth > 0) tr.className = "txTraceDepth";

                row.cells.forEach(function (cell, i) {
                    const td = document.createElement("td");
                    const cls = traceCellClass(i);
                    if (cls) td.className = cls;
                    setCellContent(td, cell);
                    tr.appendChild(td);
                });
                tbody.appendChild(tr);
            });
        }

        table.appendChild(tbody);
        return table;
    }

    async function fetchRawTrace(txHash) {
        const rpcUrl = getRpcUrl();
        if (!rpcUrl) {
            throw new Error("RPC URL not available (web3 provider or RPC_URL)");
        }

        const response = await fetch(rpcUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                jsonrpc: "2.0",
                method: "debug_traceTransaction",
                params: [txHash, { tracer: "callTracer" }],
                id: 1,
            }),
        });

        const payload = await response.json();
        if (payload.error) {
            throw new Error(payload.error.message || "debug_traceTransaction failed");
        }
        return payload.result || null;
    }

    function buildTraceRows(trace) {
        const rows = [];
        const seq = { counter: 1 };
        flattenTraceSteps(trace, 0, seq, rows);
        return rows;
    }

    // ---------- LOAD ----------
    async function loadTxLogs(txHash) {

        container.innerHTML = "⏳ Loading...";
        summaryDiv.innerHTML = "";

        try {
            const hash = normalizeHash(txHash);

            if (!hash || !web3.utils.isHex(hash) || hash.length !== 66) {
                alert("Enter a valid transaction hash");
                return;
            }

            const [tx, receipt, trace] = await Promise.all([
                web3.eth.getTransaction(hash),
                web3.eth.getTransactionReceipt(hash),
                fetchRawTrace(hash).catch(function (err) {
                    console.warn("Trace fetch failed:", err);
                    return null;
                }),
            ]);

            if (!receipt) {
                container.innerHTML = "❌ Receipt not found";
                return;
            }

            const statusOk = receipt.status === true || receipt.status === "0x1" || Number(receipt.status) === 1;
            const logs = receipt.logs || [];

            const decodedEvents = {
                LogTxns: [],
                CapReset: [],
                TVLClaimTxnLog: [],
                EthTransferred: [],
                TransferSingle: [],
                TransferBatch: [],
                ApprovalForAll: [],
            };

            let unknownCount = 0;
            const allRows = [];

            logs.forEach(function (log, idx) {
                const parsed = decodeLog(log);
                if (parsed) {
                    decodedEvents[parsed.eventName].push(parsed);
                } else {
                    unknownCount++;
                }

                allRows.push([
                    String(log.logIndex != null ? log.logIndex : idx),
                    shortAddr(log.address),
                    parsed ? parsed.eventName : "Unknown",
                    parsed ? summarizeLog(parsed) : summarizeRawLog(log),
                ]);
            });

            addRow(summaryDiv, "Tx Hash", hash);
            addRow(summaryDiv, "Block", String(receipt.blockNumber));
            addRow(summaryDiv, "Status", statusOk ? "Success" : "Failed");
            addSummaryRow(summaryDiv, "From", tx ? shortAddr(tx.from) : "-");
            addSummaryRow(summaryDiv, "To", tx ? shortAddr(tx.to || "(contract creation)") : "-");
            addRow(summaryDiv, "Value", tx ? formatOZN(tx.value) + " OZN" : "-");
            addRow(summaryDiv, "Gas Used", String(receipt.gasUsed));
            addSummaryRow(summaryDiv, "Input", decodeInputCall(tx));
            addRow(summaryDiv, "Total Logs", String(logs.length));
            addRow(
                summaryDiv,
                "Matched",
                "LogTxns: " + decodedEvents.LogTxns.length +
                " | CapReset: " + decodedEvents.CapReset.length +
                " | TVLClaimTxnLog: " + decodedEvents.TVLClaimTxnLog.length +
                " | EthTransferred: " + decodedEvents.EthTransferred.length +
                " | TransferSingle: " + decodedEvents.TransferSingle.length +
                " | TransferBatch: " + decodedEvents.TransferBatch.length +
                " | ApprovalForAll: " + decodedEvents.ApprovalForAll.length +
                (unknownCount ? " | Other: " + unknownCount : "")
            );

            if (!statusOk && logs.length === 0) {
                addRow(summaryDiv, "Note", "Failed tx reverts state — logs usually empty.");
            }

            let traceRows = [];
            let internalTxnRows = [];
            if (trace) {
                traceRows = buildTraceRows(trace);
                internalTxnRows = buildInternalTxnRows(trace, tx, statusOk);
                addRow(summaryDiv, "Trace Root", trace.error || "Success");
                addRow(summaryDiv, "Trace Steps", String(traceRows.length));
                addRow(
                    summaryDiv,
                    "Internal Txns",
                    String(Math.max(internalTxnRows.length - 1, 0)) +
                    " | Value transfers: " + String(countInternalValueTransfers(internalTxnRows))
                );
            } else {
                addRow(summaryDiv, "Trace", "Unavailable (RPC debug_traceTransaction)");
                addRow(summaryDiv, "Internal Txns", "Unavailable (requires trace)");
            }

            container.innerHTML = "";

            appendTable(
                container,
                "All Transaction Logs",
                createTable(["#", "Contract", "Event", "Details"], allRows)
            );

            appendTable(
                container,
                "LogTxns",
                createTable(
                    ["#", "Contract", "From", "ORC1155", "Amt", "Value", "Time", "Type"],
                    decodedEvents.LogTxns.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            shortAddr(d.from),
                            shortAddr(d.orc1155),
                            formatOZN(d._amt),
                            formatOZN(d._value),
                            logAgeLabel(d._time),
                            logTypeLabel(Number(d._type)),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "CapReset",
                createTable(
                    ["#", "Contract", "Invested", "Claimed", "Claimed$", "Invested$", "Burned", "Burned$", "Age"],
                    decodedEvents.CapReset.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            formatOZN(d.invested),
                            formatOZN(d.claimed),
                            formatOZN(d.claimedDollar),
                            formatOZN(d.investedDollar),
                            formatOZN(d.burned),
                            formatOZN(d.burnedDollar),
                            logAgeLabel(d.ag),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "TVLClaimTxnLog",
                createTable(
                    ["#", "Contract", "To", "Value", "Flush", "Time"],
                    decodedEvents.TVLClaimTxnLog.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            shortAddr(d.to),
                            formatOZN(d.value),
                            formatOZN(d.flush),
                            logAgeLabel(d._time),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "EthTransferred",
                createTable(
                    ["#", "Contract", "To", "Amount"],
                    decodedEvents.EthTransferred.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            shortAddr(d.to),
                            formatOZN(d.amount),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "TransferSingle (ERC1155)",
                createTable(
                    ["#", "Contract", "Operator", "From", "To", "Id", "Value"],
                    decodedEvents.TransferSingle.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            shortAddr(d.operator),
                            shortAddr(d.from),
                            shortAddr(d.to),
                            String(d.id),
                            String(d.value),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "TransferBatch (ERC1155)",
                createTable(
                    ["#", "Contract", "Operator", "From", "To", "Ids", "Values"],
                    decodedEvents.TransferBatch.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            shortAddr(d.operator),
                            shortAddr(d.from),
                            shortAddr(d.to),
                            formatUintArray(d.ids),
                            formatUintArray(d.values),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "ApprovalForAll (ERC1155)",
                createTable(
                    ["#", "Contract", "Account", "Operator", "Approved"],
                    decodedEvents.ApprovalForAll.map(function (ev) {
                        const d = ev.decoded;
                        return [
                            String(ev.logIndex),
                            shortAddr(ev.address),
                            shortAddr(d.account),
                            shortAddr(d.operator),
                            String(d.approved),
                        ];
                    })
                )
            );

            appendTable(
                container,
                "Internal Transactions (from RPC trace)",
                createInternalTxnTable(
                    ["#", "Depth", "Kind", "Type", "From", "To", "Value", "Gas Used", "Status", "Input"],
                    internalTxnRows
                )
            );

            appendTable(
                container,
                "Raw Execution Trace (sequential)",
                createTraceTable(
                    ["#", "Depth", "Type", "From", "To", "Value", "Gas Used", "Input", "Output / Error"],
                    traceRows
                )
            );

            if (!trace) {
                const traceNote = document.createElement("div");
                traceNote.style.color = "#ff9f43";
                traceNote.style.marginTop = "6px";
                traceNote.style.fontSize = "12px";
                traceNote.innerText =
                    "Trace / internal txns unavailable. Ensure the RPC endpoint supports debug_traceTransaction " +
                    "(parsed locally from callTracer — no explorer API).";
                container.appendChild(traceNote);
            }

        } catch (e) {
            console.error(e);
            container.innerHTML = "❌ Error: " + (e.message || e);
        }
    }

    // ---------- CLICK ----------
    btn.onclick = () => {
        const hash = input.value.trim();
        if (!hash) return alert("Enter transaction hash");
        loadTxLogs(hash);
    };

    input.addEventListener("keypress", (e) => {
        if (e.key === "Enter") btn.click();
    });

    bindCopyClick(panel);
}


async function onCreateTemplate(tid) {
    showLoader();

    try {
        window.web3T = new Web3(window.ethereum);
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });

        //

        var calldata = '';

        if (tid == 1) calldata = ChangeParent;
        else if (tid == 2) calldata = ChangeOwner;
        else if (tid == 3) calldata = SuspendIncome;
        else if (tid == 4) calldata = LockUser;
        else if (tid == 5) calldata = ClaimPerDay;
        else if (tid == 6) calldata = SecureBase;
        else if (tid == 7) calldata = DAOWinPer;
        else if (tid == 8) calldata = DAOBlacklist;
        else { alert('No Template found'); return; }
        // estimate gas

        const txHash = await window.ethereum.request({
            method: "eth_sendTransaction",
            params: [{
                from: accounts[0],
                to: indaocore,
                data: calldata
            }]
        });

        // wait for receipt
        const receipt = await web3.eth.getTransactionReceipt(txHash);

        console.log(receipt);

        if (receipt && receipt.status)
            alert("Template succeeded");
        else
            alert("Template failed");

    } catch (err) {

        console.error(err);
        alert("Template failed: " + (err.message || err));
    }

    hideLoader();

}

// -------------------- LOAD RULE --------------------
async function loadRule() {
    clearPanels();
    showLoader();
    try {

        // ---------------- LEVEL CLAUSES (TABLE) ----------------
        const panelLevel = addPanel("Level Clauses");

        // create table
        const table = document.createElement("table");
        table.border = "1";
        table.style.width = "100%";

        // header
        table.innerHTML = `
        <thead>
        <tr>
        <th>Level</th>
        <th>Rank required</th>
        <th>REWARD %</th>
        <th>LEVEL %</th>
        </tr>
        </thead>
        <tbody id="levelClauseBody"></tbody>
        `;

        panelLevel.appendChild(table);

        // helper for percentage
        function toPercent(num, den) {
            if (parseInt(den) === 0) return "0%";
            return (parseFloat(num) / parseFloat(den)) + "%";
        }

        // load data
        for (let i = 1; i <= 15; i++) {
            try {
                const lvl = await rule.methods.levelClause(i).call();

                const rwPercent = toPercent(lvl.rwNum, lvl.rwrDen);
                const yeiPercent = toPercent(lvl.yeiNum, lvl.yeiDen);

                document.getElementById("levelClauseBody")
                    .insertAdjacentHTML("beforeend",
                        `<tr>
                            <td>${i}</td>
                            <td>${lvl.rank}</td>
                            <td>${rwPercent}</td>
                            <td>${yeiPercent}</td>
                        </tr>`
                    );

            } catch (e) {
                console.log("Level error:", i);
            }
        }


        // ---------------- RANK CLAUSES (TABLE) ----------------
        const panelRank = addPanel("Rank Clauses");

        // create table
        const tableRank = document.createElement("table");
        tableRank.border = "1";
        tableRank.style.width = "100%";

        // header
        tableRank.innerHTML = `
        <thead>
        <tr>
        <th>Rank</th>
        <th>Direct Required</th>
        <th>NFT Amount</th>
        <th>Eligible Rank</th>
        <th>Grace Amount</th>
        <th>Grace Period</th>
        </tr>
        </thead>
        <tbody id="rankClauseBody"></tbody>
        `;

        panelRank.appendChild(tableRank);

        // load data
        for (let i = 0; i <= 7; i++) {
            try {
                const r = await rule.methods.rankClause(i).call();
                rankClauses[i] = {
                    direct: Number(r.direct),
                    nftAmount: Number(r.nftAmount),
                    eRnk: Number(r.eRnk),
                    gRnk: Number(r.gRnk),
                    gPrd: Number(r.gPrd),
                };
                document.getElementById("rankClauseBody")
                    .insertAdjacentHTML("beforeend",
                        `<tr>
                            <td>${i}</td>
                            <td>${r.direct}</td>
                            <td>${r.nftAmount}</td>
                            <td>${r.eRnk}</td>
                            <td>${r.gRnk}</td>
                            <td>${r.gPrd}</td>
                        </tr>`
                    );

            } catch (e) {
                console.log("Rank error:", i);
            }
        }
        // ---------------- ROYALTY CLAUSES (TABLE) ----------------
        const panelRoyal = addPanel("Royalty");

        // create table
        const tableRoyal = document.createElement("table");
        tableRoyal.border = "1";
        tableRoyal.style.width = "100%";

        // header
        tableRoyal.innerHTML = `
        <thead>
        <tr>
        <th>Royal #</th>
        <th>Percentage</th>
        <th>End (days)</th>
        </tr>
        </thead>
        <tbody id="royalClauseBody"></tbody>
        `;

        panelRoyal.appendChild(tableRoyal);

        // helper for %
        function toPercent(num, den) {
            if (parseInt(den) === 0) return "0%";
            let val = parseFloat(num) / parseFloat(den);
            return parseFloat(val.toFixed(2)) + "%"; // removes trailing zeros
        }

        // load data
        for (let i = 1; i <= 7; i++) {
            try {
                const rw = await rule.methods.royalityClause(i).call();

                if (parseInt(rw.rwNum) === 0) continue;
                const percent = toPercent(rw.rwNum, rw.rwDen);

                document.getElementById("royalClauseBody")
                    .insertAdjacentHTML("beforeend",
                        `<tr>
                            <td>${i}</td>
                            <td>${percent}</td>
                            <td>${rw.rwEnd}</td>
                        </tr>`
                    );

            } catch (e) {
                console.log("Royal error:", i);
            }
        }

        // ---------------- POOL (TABLE - CLEAN) ----------------
        const panelPool = addPanel("Pool");

        const pool = await rule.methods.pool().call();

        // helper for %
        function toPercent(num, den) {
            if (parseInt(den) === 0) return "0%";
            return parseFloat((parseFloat(num) / parseFloat(den)).toFixed(2)) + "%";
        }

        // create table
        const tablePool = document.createElement("table");
        tablePool.border = "1";
        tablePool.style.width = "100%";

        tablePool.innerHTML = `
        <thead>
        <tr>
        <th>Parameter</th>
        <th>Value</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>Start After</td>
            <td>${pool.startafter}</td>
        </tr>
        <tr>
            <td>Stake</td>
            <td>${toPercent(pool.stakeN, pool.stakeD)}
                <small>(${pool.stakeN}/${pool.stakeD})</small> 
            </td>
        </tr>
        <tr>
            <td>ROI</td>
            <td>${toPercent(pool.roiN, pool.roiD)} 
                <small>(${pool.roiN}/${pool.roiD})</small>
            </td>
        </tr>
        <tr>
            <td>ROI Interval (days)</td>
            <td>${pool.roiInt}</td>
        </tr>
        <tr>
            <td>ROI End (days)</td>
            <td>${pool.roiEnd}</td>
        </tr>
        </tbody>
        `;

        panelPool.appendChild(tablePool);

        // ---------------- NFT POOLS (TABLE) ----------------
        const panelNFTPool = addPanel("NFT Pools (StartFrom: 270 days for 2025, 180 days for 2026))");

        const nft1 = await rule.methods.poolNFT1().call();
        const nft2 = await rule.methods.poolNFT2().call();

        // helper for %
        function toPercent(num, den) {
            if (parseInt(den) === 0) return "0%";
            return parseFloat((parseFloat(num) / parseFloat(den)).toFixed(2)) + "%";
        }

        // create table
        const tableNFT = document.createElement("table");
        tableNFT.border = "1";
        tableNFT.style.width = "100%";

        tableNFT.innerHTML = `
        <thead>
        <tr>
        <th>Pool</th>
        <th>ROI</th>
        <th>Interval (days)</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>NFT1</td>
            <td>${toPercent(nft1.roiN, nft1.roiD)} 
                <small>(${nft1.roiN}/${nft1.roiD})</small>
            </td>
            <td>${nft1.roiInt}</td>
        </tr>
        <tr>
            <td>NFT2</td>
            <td>${toPercent(nft2.roiN, nft2.roiD)} 
                <small>(${nft2.roiN}/${nft2.roiD})</small>
            </td>
            <td>${nft2.roiInt}</td>
        </tr>
        </tbody>
        `;

        panelNFTPool.appendChild(tableNFT);

        // ---------------- MINT SETTINGS ----------------
        const panelMint = addPanel("Mint Config");

        const minQty = await rule.methods.minMintQty().call();
        const maxQty = await rule.methods.maxMintQty().call();
        const fee = await rule.methods.mintFeePerQty().call();
        const cycleDays = await rule.methods.mintCycleDays().call();
        const maxPerCycle = await rule.methods.maxMintsPerCycle().call();

        // min + max qty
        addRow(panelMint, "Mint Quantity Range", `${minQty} - ${maxQty}`);

        // cycle info
        addRow(panelMint, "Mint Limit", `${maxPerCycle} mints allowed in ${cycleDays} days`);

        // fee per qty
        addRow(panelMint, "Mint Price", `${fee}$ per NFT`);

        // ---------------- CLAIM SETTINGS ----------------
        const panelClaim = addPanel("Claim Config");

        const minClaim = parseFloat(web3.utils.fromWei((await rule.methods.minClaimPerDay().call()).toString(), "ether")).toFixed(3);
        const maxClaim = parseFloat(web3.utils.fromWei((await rule.methods.maxClaimPerDay().call()).toString(), "ether")).toFixed(3);
        const globalClaim = parseFloat(web3.utils.fromWei((await rule.methods.maxGlobalClaimPerDay().call()).toString(), "ether")).toFixed(3)
        const cycle = await rule.methods.eachclaimCycle().call();

        // min + max in single row
        addRow(panelClaim, "Claim Limit", `${minClaim} OZN - ${maxClaim} OZN`);

        // claim cycle meaning
        addRow(panelClaim, "Claim Frequency", `1 claim allowed every ${cycle} days`);

        // global claim meaning
        addRow(panelClaim, "Daily Claim qouta- Global", `Max ${globalClaim} OZN claimable per day`);

        // ---------------- NFT SETTINGS ----------------
        const panelNFT = addPanel("NFT Config");

        const maxSend = await rule.methods.maxNFTSend().call();
        const perCycle = await rule.methods.NFTSendPerCycle().call();

        addRow(panelNFT, "NFT Send", `${maxSend} NFTs allowed to send in ${perCycle} days`);

        // ---------------- DAO ----------------
        const panelDAO = addPanel("DAO");

        addRow(panelDAO, "Eligible Rank For DAO", await rule.methods.rankforDAO().call());

        // ---------------- DELEGATION Config----------------
        const panelDelegation = addPanel("Delegation Config");

        // delegator count
        addRow(panelDelegation, "Delegator Count", await rule.methods._delegatorCount().call());

        // helper for %
        function toPercent(num, den) {
            if (parseInt(den) === 0) return "0%";
            return parseFloat((parseFloat(num) / parseFloat(den)).toFixed(2)) + "%";
        }

        // validator configs
        const valInternal = await rule.methods.valInternal().call();
        const valExternal = await rule.methods.valExternal().call();

        // grouped view
        addRow(panelDelegation, "Internal",
            `Qty:${valInternal.qtyORmul} | ROI:${toPercent(valInternal.roiN, valInternal.roiD)} (${valInternal.roiN}/${valInternal.roiD}) | Int:${valInternal.roiInt}`
        );

        addRow(panelDelegation, "External",
            `Qty:${valExternal.qtyORmul} | ROI:${toPercent(valExternal.roiN, valExternal.roiD)} (${valExternal.roiN}/${valExternal.roiD}) | Int:${valExternal.roiInt}`
        );


        // ---------------- CAPPING ----------------
        const panelCap = addPanel("Capping");

        const cap = await rule.methods.capping().call();
        addRow(panelCap, "Multiple", cap.multiple);
        addRow(panelCap, "multipledollar", cap.multipledollar);



        // ---------------- TOUR ----------------
        const panelTour = addPanel("Tour");

        for (let i = 1; i <= 7; i++) {
            try {
                const t = await rule.methods.tourClause(i).call();

                const ct = await rule.methods.computeTour(i).call();

                // skip if 0
                if (parseInt(t) === 0) continue;

                // convert wei → ether (3 decimal)
                addRow(panelTour, `Tour ${i}`, `${t.toString()}$ ~ ${formatOZN(ct)}`);

            } catch (e) {
                console.log("Tour error:", i);
            }
        }


        // ---------------- OTHER SETTINGS ----------------
        const panelOthers = addPanel("OTHER SETTINGS");
        sysAge = await rule.methods.systemAge().call();
        document.getElementById("sysAgeid").innerHTML = sysAge;
        addRow(panelOthers, "Owner", await rule.methods.owner().call());
        addRow(panelOthers, "System Age", `${getAgeDateRange(sysAge).start} {${sysAge}}`);
        const system = await rule.methods.system().call();
        addRow(panelOthers, "Shutdown", system.shutdown);
        addRow(panelOthers, "Is Safe", await rule.methods._isSafe().call());
        addRow(panelOthers, "Allow Force Transfer", await rule.methods.allowForceTransfer().call());
        // ✅ NEW
        addRow(panelOthers, "Free Intervals", await rule.methods.freeIntervals().call());
        addRow(panelOthers, "Session_TTL (Seconds)", await rule.methods.sessionTTLSeconds().call());

    } catch (err) {
        console.error(err);
        const panelErr = addPanel("Error");
        addRow(panelErr, "Error", "Failed to load rule data");
    }


    const btnUplineDownline = document.createElement("button");
    btnUplineDownline.textContent = "Load View";
    btnUplineDownline.style.padding = "8px 14px";
    btnUplineDownline.style.borderRadius = "8px";
    btnUplineDownline.style.background = "linear-gradient(135deg,#00ffff,#3fa9ff)";
    btnUplineDownline.style.border = "none";
    const panelUplineDownline = addPanel("🌳 Upline + Downline View");
    panelUplineDownline.appendChild(btnUplineDownline);
    // ---------- CLICK ----------
    btnUplineDownline.onclick = () => {
        renderULTreePanel();
    };
    hideLoader();
}

function getGraphConfigOld(n) {
    const maxRange = n + 2;
    let axisTitle = "Value";
    let formatter;



    // 1. Handle extremely small numbers (e.g., 0.00000004)
    if (n > 0 && n < 0.0001) {
        const exponent = Math.floor(Math.log10(n));
        axisTitle = `Value (×10^${exponent})`;
        // Scaled ticks (e.g., 4.0 instead of 0.00000004)
        formatter = (val) => (val * Math.pow(10, -exponent)).toFixed(1);
    }

    // 2. Handle numbers with decimals (e.g., 12.004)
    else if (n % 1 !== 0) {
        axisTitle = "Value";
        formatter = (val) => val.toFixed(2); // Keep labels short
    }

    // 3. Handle standard whole numbers
    else {
        axisTitle = "Value";
        formatter = (val) => Math.round(val);
    }



    return {
        range: [0, maxRange],
        title: axisTitle,
        tickFormatter: formatter
    };
}



// Examples:
//console.log(getGraphConfigOld(0.00000004)); // Title: "Value (×10^-8)", Range: [0, 2.00000004]
//console.log(getGraphConfigOld(12.004)); // Title: "Value", Range: [0, 14.004]
// ----------------------------
function round2(n) {
    return Number(n.toFixed(2));
}

// ----------------------------
function classifyInput(n) {
    if (n === null || n === undefined || isNaN(n)) {
        return { type: "zero", value: 0 };
    }

    n = Number(n);

    if (n === 0) {
        return { type: "zero", value: 0 };
    }

    return { type: "normal", value: n };
}

// ----------------------------
function normalizeSmall(n) {
    let value = Math.abs(n);
    let shift = 0;

    while (value < 0.1) {
        value *= 10;
        shift++;
    }

    return {
        scaledValue: value,
        scaleFactor: shift
    };
}

// ----------------------------
// 🔥 CORE MAPPING (CLEAN)
// ----------------------------
function mapToGraph(value, scaleRatio, range) {

    if (!value || isNaN(value)) {
        return {
            value: 0,
            isMin: true,
            isMax: false
        };
    }

    let scaled = value * scaleRatio;

    let clamped = Math.max(range[0], Math.min(range[1], scaled));

    return {
        value: round2(clamped),
        isMin: clamped === range[0],
        isMax: clamped === range[1]
    };
}

// ----------------------------
// 🔥 MAIN FUNCTION
// ----------------------------
function getGraphConfig(thresholdInput, currentValue = 0, burned4x = 0) {

    const classified = classifyInput(thresholdInput);

    // ZERO CASE
    if (classified.type === "zero") {
        return {
            threshold: 0,
            range: [0, 0],
            ticks: Array(11).fill(0),

            current: { value: 0, isMin: true, isMax: false },
            burned: { value: 0, isMin: true, isMax: false }
        };
    }

    let rawThreshold = classified.value;

    let scaledThreshold = rawThreshold;
    let scaleFactor = 1;

    // SCALE SMALL VALUES
    if (Math.abs(rawThreshold) < 0.001) {
        const res = normalizeSmall(rawThreshold);
        scaledThreshold = res.scaledValue;
        scaleFactor = res.scaleFactor;
    }

    scaledThreshold = round2(scaledThreshold);

    // GRAPH BUILD
    const step = scaledThreshold / 9;

    let max = step * 10;

    // ✅ SCALE RATIO
    const scaleRatio = rawThreshold !== 0
        ? scaledThreshold / rawThreshold
        : 0;

    // 🔥 PRE-SCALE values
    const scaledCurrent = currentValue * scaleRatio;
    const scaledBurned = burned4x * scaleRatio;

    // 🔥 AUTO EXPAND (prevents clipping)
    max = Math.max(max, scaledCurrent, scaledBurned);

    max = round2(max);

    const range = [0, max];

    // 🔥 recompute step based on final max
    const finalStep = max / 10;

    const ticks = Array.from({ length: 11 }, (_, i) =>
        round2(i * finalStep)
    );

    // MAP VALUES
    const current = mapToGraph(currentValue, scaleRatio, range);
    const burned = mapToGraph(burned4x, scaleRatio, range);

    return {
        rawThreshold,
        currentValue,
        burned4x,
        scaledThreshold,
        scaleFactor,
        scaleRatio,
        step: round2(finalStep),
        range,

        ticks,

        thresholdTickIndex: 9, // approximate now (may shift slightly)
        maxTickIndex: 10,

        tickAtIndex9: ticks[9],
        tickAtIndex10: ticks[10],

        current,
        burned
    };
}
const tests = [
    { t: 12, c: 10, b: 5 },
    { t: 12.4, c: 15, b: 8 },
    { t: 12.0004, c: 20, b: 1 },

    { t: 0.124, c: 0.5, b: 0.2 },

    { t: 0.00000000124, c: 0.54546, b: 0.2 },

    { t: 0, c: 10, b: 2 },
    { t: null, c: 5, b: 1 },
    { t: undefined, c: 2, b: 0.5 }
];
/*
tests.forEach(({ t, c, b }) => {
 
    console.log("\n====================");
 
    const res = getGraphConfig(t, c, b);
 
    console.log("INPUT →",
        "Threshold:", t,
        "| Current:", c,
        "| Burned:", b
    );
 
    console.log("\n--- SCALED VALUES ---");
    console.log("SCALED →",
        "Threshold:",  res.threshold,
        "| Current:", res.current.value,
        "| Burned:", res.burned.value
    );
 
    console.log("\n--- SCALE INFO ---");
    console.log("Scale Factor:", res.scaleFactor);
    console.log("Raw Threshold:", res.rawThreshold);
    console.log("Scaled Threshold:", res.scaledThreshold);
 
    console.log("\n--- RANGE ---");
    console.log("Range:", res.range);
    console.log("Step :", res.step);
 
    console.log("\n--- TICKS ---");
    console.log(res.ticks);
});
 */

async function loadGraph(cp) {
    /* cp = {
         totalIncome: 70.6,
         burned4x: 13.0,
         threshold: 12.4,
         cap: false,
         currentValue: 11.6
     }; */


    const s = getGraphConfig(cp.threshold, cp.currentValue, cp.burned4x);

    console.log(s);

    let minvalue = s.range[0];
    let maxvalue = s.range[1];
    let alertvalue = s.ticks[8];

    let statuscolor = cp.cap ? '#ff3c00' : (s.current.value >= s.ticks[8] ? '#f5e664' : '#55BF3B');

    Highcharts.chart('container', {

        chart: {
            type: 'gauge',
            plotBackgroundColor: null,
            plotBackgroundImage: null,
            plotBorderWidth: 0,
            plotShadow: false,
            height: '80%',
            backgroundColor: '#0f172a' // deep dark
        },

        title: {
            useHTML: true,
            text: `
            <span style="font-size:17px; color:#ccc;">Capping: 
                <span style="color:${statuscolor}; font-weight:600;font-size:16px;">
                    ${cp.cap ? 'ACTIVE' : (s.current.value >= s.ticks[8] ? 'WARNING' : 'NORMAL')}
                </span> </span>
                
            `,
            x: 10,   // 👉 move right (+) / left (-)
            y: 60     // 👉 move down (+) / up (-)
        },

        credits: {
            enabled: false
        },

        exporting: {
            enabled: false
        },

        pane: {
            startAngle: -90,
            endAngle: 89.9,
            background: null,
            center: ['50%', '75%'],
            size: '110%'
        },

        // the value axis
        yAxis: [{
            min: s.ticks[0],
            max: s.ticks[10],
            tickPixelInterval: 72,
            tickPosition: 'inside',
            //tickColor: 'var(--highcharts-background-color, #FFFFFF)',
            tickPositions: [s.ticks[0], s.current.value, s.ticks[9], s.ticks[10]], // Add 72 here
            tickLength: 20,
            tickWidth: 2,
            minorTickInterval: null,
            labels: {
                distance: 20,
                style: {
                    fontSize: '14px',
                    color: '#fff'
                },
                formatter: function () {
                    var t = '<span color="grey">' + this.value.toString() + '</span>';

                    //if(this.value == s.ticks[8]) t = '<span color="yellow">⚠</span>';
                    if (this.value == s.ticks[9]) t = '<span color="red">T</span>';
                    if (this.value == s.current.value) t = '<span color="' + statuscolor + '">C</span>';
                    if (this.value == s.ticks[10]) t = '<span color="grey">max</span>';

                    return t;
                }
            },
            title: {
                text: `<div style="text-align:center; width:220px;">
                        <div style="
                            font-size:16px;
                            font-weight:700;
                            color:#22c55e;
                            letter-spacing:1px;
                        ">
                            ${cp.currentValue}<br/>
                            <span style="
                                font-size:13px;
                                color:#94a3b8;
                                margin-top:2px;
                            "> Current Value </span>
                        </div>

                     
                    </div>`,
                y: 40
            },
            lineWidth: 0,
            plotBands: [
                {
                    from: s.ticks[0],
                    to: s.ticks[9],
                    color: {
                        linearGradient: { x1: 0, y1: 0, x2: 1, y2: 0 },
                        stops: [
                            [0, '#55BF3B'], // Start: Green
                            [0.35, '#55BF3B'], // Middle: Yellow
                            [0.7, '#DDDF0D'], // Middle: Yellow
                            [0.95, '#DDDF0D'], // Middle: Yellow
                            [1, '#8B0000']  // End: Dark Red
                        ]
                    },
                    thickness: 15
                },
                {
                    from: s.ticks[9],
                    to: s.ticks[10],
                    color: '#7f1d1d', // dark red
                    thickness: 20
                }
            ]
        }, {
            min: s.ticks[0],
            max: s.ticks[10],
            /*title: {
                text: 'BURNED'
            },*/
            tickPositions: [s.ticks[0], s.burned.value, s.ticks[10]], // Add 72 here
            lineColor: '#020102',
            tickColor: '#8b5cf6',
            reversed: true,
            minorTickColor: '#8b5cf6',
            offset: -60,
            lineWidth: 0,
            labels: {
                distance: 5,
                //rotation: 'auto',
                formatter: function () {
                    var t = '<span>' + this.value + '</span>';
                    if (this.value == s.burned.value) t = `<span style="
                            display:inline-flex;
                            align-items:center;
                            justify-content:center;
                            width:18px;
                            height:18px;
                            border-radius:50%;
                            background:#8b5cf6;   /* violet */
                            font-weight:600;
                        ">
                            B
                        </span>`;
                    if (this.value == s.ticks[10]) t = '<span">max</span>';
                    return t;
                },
                style: {
                    color: 'Violet',
                    fontWeight: 'normal',
                    fontSize: '13px'
                }

            },
            tickLength: 5,

            minorTickLength: 1,
            endOnTick: false,
            plotBands: [{
                from: s.ticks[0],
                to: s.burned.value,
                color: 'Violet', // Violet
                thickness: 5,
                innerRadius: '60%',  // Tuck this band INSIDE
                outerRadius: '55%',

            }]

        }],

        series: [{
            name: 'current: ',
            data: [s.current.value],
            tooltip: {
                enabled: false
            },
            dataLabels: {
                useHTML: true,
                x: -10,   // move right (+) or left (-)
                y: 20,   // move up (-) or down (+)
                format: `<!-- 📊 INFO BLOCK -->
                        <table align="left" style="color:grey; letter-spacing:1px;line-spacing:1px; text-align: left;font-weight: normal;width: 137%; border-collapse: collapse;" cellpadding="2"><tbody>
                        <tr><td width="100px">Income</td><td>${cp.totalIncome}</td></tr>
                        <tr><td>Threshold</td><td>${cp.threshold}</td></tr>
                        <tr><td>BurnedX</td><td>${cp.burned4x}</td></tr>
                        </tbody></table>`,
                borderWidth: 0,

                style: {
                    fontSize: '13px'
                }
            },
            /*dial: {
                radius: '80%',
                backgroundColor: 'white',
                baseColor: 'red',
                baseWidth: 10,
                baseLength: '0%',
                rearLength: '0%'
            }*/
            dial: {
                radius: '100%',
                baseWidth: 0,
                rearLength: '0%',
                topWidth: 1,
                backgroundColor: '#F5F5F5',
                borderWidth: 0,
            },
            pivot: {
                backgroundColor: 'grey',
                radius: 9
            }

        }, {
            name: 'Burned',
            data: [0.1],
            tooltip: {
                enabled: false
            },
            dial: {
                radius: '60%',
                baseWidth: 1,
                rearLength: '0%',
                topWidth: 1,
                backgroundColor: 'red',
                borderWidth: 0,
            },
            pivot: {
                backgroundColor: 'grey',
                radius: 9
            },
        }]

    });





}



async function connectWallet() {
    currentAccount = null;
    currentInstance = null;
    currentStor = null;

    if (!window.ethereum) {
        alert("MetaMask not installed");
        return;
    }

    try {

        const accounts = await window.ethereum.request({
            method: 'eth_requestAccounts'
        });

        currentAccount = accounts[0];

        showWallet();
        await addConnectedUserPanel();
    } catch (err) {
        console.error(err);
    }

}
function showWallet() {

    const short = currentAccount.slice(0, 6) + "..." + currentAccount.slice(-4);

    document.getElementById("walletAddr").innerText = short;

    document.getElementById("connectBtn").style.display = "none";
    document.getElementById("walletInfoLine").style.display = "flex";


}

function disconnectWallet() {

    currentAccount = null;
    currentInstance = null;
    currentStor = null;

    document.getElementById("walletInfoLine").style.display = "none";

    document.getElementById("connectBtn").style.display = "inline-block";

}

function copyWallet() {

    if (!currentAccount) return;

    navigator.clipboard.writeText(currentAccount);

}

function formatDate(date) {
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0');
    const yyyy = date.getFullYear();
    return `${dd}-${mm}-${yyyy}`;
}

function getAgeDateRange(age) {
    const baseDate = new Date("2025-07-17T22:00:00"); // 10:00 PM

    // Start date = base + (age - 1) days
    const start = new Date(baseDate);
    start.setDate(start.getDate() + (age - 1));

    // End date = start + 1 day
    const end = new Date(start);
    end.setDate(end.getDate() + 1);

    return {
        start: formatDate(start),
        end: formatDate(end)
    };
}

window.onload = load;

document.addEventListener("click", async (e) => {
    if (e.target.classList.contains("clickableAddr")) {

        const fullAddr = e.target.dataset.full;

        await navigator.clipboard.writeText(fullAddr);

        const oldText = e.target.innerText;

        e.target.innerText = "Copied ✓";
        e.target.style.opacity = "0.5";

        setTimeout(() => {
            e.target.innerText = oldText;
            e.target.style.opacity = "1";
        }, 800);
    }
});